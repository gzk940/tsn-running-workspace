@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"

REM ============================================================
REM  体适能 · 最新版 · 工作台启动器
REM
REM  双击           → 开窗口（有 pywebview 用它，没有就用系统浏览器）
REM  最新版.bat n → 只起服务，不开窗口（自己拿浏览器开地址）
REM
REM  环境变量 TSN_PY 可以强行指定解释器（装了多个 Python 时用）
REM ============================================================

set "PY="
set "PYARG="

REM ---- 1) 找一个 import Crypto 能过的 Python ----
call :probe_exe "%~dp0.venv\Scripts\python.exe"
call :probe_exe "%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
call :probe_py3
call :probe_cmd python

if defined TSN_PY (
    "%TSN_PY%" -c "import Crypto" >nul 2>&1
    if not errorlevel 1 (
        set "PY=%TSN_PY%"
        set "PYARG="
    )
)

if not defined PY goto :no_python

REM ---- 2) 挑一对空闲端口（双击多次 = 多开，互不干扰）----
set "WSP="
set "MP="
for /l %%N in (0,1,19) do call :try_port %%N
if not defined WSP goto :no_port

REM ---- 3) 起服务 ----
set "NOWIN="
if /i "%~1"=="n" set "NOWIN=--no-window"

echo [START] 体适能 · 最新版 · 工作台
echo   地址   : http://127.0.0.1:!WSP!
echo   mock   : http://127.0.0.1:!MP!   （只监听本机，不连真实服务器）
echo   解释器 : !PY! !PYARG!
echo   提示   : 登录后地图上会出现红色打卡点，照着它画线，再点「一键开跑」。
echo            再双击一次本脚本可开第二个实例（端口自动错开）。
echo.

start "" "!PY!" !PYARG! app.py --ws-port !WSP! --mock-port !MP! !NOWIN!
exit /b 0

REM ============================================================ 子程序
:probe_exe
REM %1 = 候选解释器路径（带引号）
if defined PY goto :eof
if not exist %1 goto :eof
%1 -c "import Crypto" >nul 2>&1
if errorlevel 1 goto :eof
set "PY=%~1"
set "PYARG="
goto :eof

:probe_py3
if defined PY goto :eof
py -3 -c "import Crypto" >nul 2>&1
if errorlevel 1 goto :eof
set "PY=py"
set "PYARG=-3"
goto :eof

:probe_cmd
if defined PY goto :eof
%1 -c "import Crypto" >nul 2>&1
if errorlevel 1 goto :eof
set "PY=%1"
set "PYARG="
goto :eof

:try_port
REM %1 = 偏移量；占用了就换下一个
if defined WSP goto :eof
set /a "P1=8770+%1"
set /a "P2=18080+%1"
netstat -ano | findstr "LISTENING" | findstr "127.0.0.1:%P1% " >nul 2>&1
if not errorlevel 1 goto :eof
netstat -ano | findstr "LISTENING" | findstr "127.0.0.1:%P2% " >nul 2>&1
if not errorlevel 1 goto :eof
set "WSP=%P1%"
set "MP=%P2%"
goto :eof

:no_python
echo.
echo [ERROR] 没找到装了 pycryptodome 的 Python。
echo         先装依赖再双击本脚本：
echo             pip install -r requirements.txt
echo         或者指定解释器后重试：
echo             set TSN_PY=C:/Python311/python.exe
echo.
pause
exit /b 1

:no_port
echo.
echo [ERROR] 8770-8789 / 18080-18099 都被占用了，先关掉几个再试。
echo.
pause
exit /b 1

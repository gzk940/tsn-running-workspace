# -*- coding: utf-8 -*-
"""policy.py —— 服务器策略归一化层（通用版的地基）。

唯一职责
--------
把**任意学校、任意链路**下发的 `getExerciseSetting` 回包，解析成**同一个** `Policy` 对象。
执行层（轨迹 / 人脸 / 打卡 / 上传）只认 `Policy`，永远不知道有学校这回事。

三条铁律
--------
1. **不出现学校名** —— 本文件里没有 `gdufe` / `zqu` / `gdust`，也没有 `if school_code ==`。
   出现了就说明又退化成"一校一定制"。
2. **不写死字段路径** —— 每个语义挂一组候选键名（见 `_ALIASES`）；别名对不上就走
   结构探针（`_probe`）在整棵树里找。新增一种写法 = 表里加一个字符串。
3. **不认识的东西不许丢** —— 原样留在 `raw` 里，并在 `unresolved` / `warnings` 里点名。
   宁可承认"这项没认出来"，也不要静默按默认值跑。

为什么需要这一层
----------------
`flow.py` 里现在散着 `_must_points` / `normalize_bean` 两段归一化，前端还有几个 `if`。
每来一所新学校，就得回去补一处 —— 那才是"一校一定制"。收进来以后，新学校只有两种情况：
命中别名（什么都不用做），或者命中探针（什么都不用做）。两者都不中，才写一份覆盖 JSON。

坐标口径
--------
服务器下发的是**高德 GCJ-02**（`geofence` / `campusList`），内部几何一律 **WGS-84**。
但有一类学校可能直接发 WGS —— 所以这里做一次**证据判定**（`_pick_crs`）：
拿围栏当尺子，哪套坐标能让打卡点落进围栏，就用哪套。判不了才按项目约定转 GCJ→WGS。
"""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

try:                                            # 坐标口径的唯一出处（没有就降级，不炸）
    import tracklib as T
except Exception:                               # noqa: BLE001
    T = None


# ============================================================ 基础取值
def _truthy(v: Any) -> bool:
    """`1` / `"1"` / `"true"` / `True` 一律算真；`None`、`0`、`"0"` 算假。"""
    if v is None:
        return False
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _num(v: Any) -> Optional[float]:
    """宽松转数字：`"3.33"` → 3.33；`""` / `None` / `True` → None。"""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        s = str(v).strip()
        return float(s) if s else None
    except (TypeError, ValueError):
        return None


def _normalize_km(v: Any) -> Optional[float]:
    """里程归一成 **km**：`>100` 视为米（真机见过 `totalRange=2500` 也有 `2.5`）。"""
    n = _num(v)
    if n is None or n <= 0:
        return None
    return n / 1000.0 if n > 100 else n


def _first(d: Dict[str, Any], keys: Sequence[str]) -> Tuple[Any, Optional[str]]:
    """按候选顺序取第一个**非空**值，返回 (值, 命中的键名)。"""
    for k in keys:
        if k in d and d[k] not in (None, "", [], {}):
            return d[k], k
    return None, None


# ============================================================ 字段别名表
# 一行一个语义，右边是候选键名（按可信度排序）。新增学校写法只往这里加字符串。
_ALIASES: Dict[str, Tuple[str, ...]] = {
    "target":      ("totalRange", "totalKilometre", "totalKilometer", "totalKm",
                    "targetRange", "targetKm", "rangeKm"),
    "speed_limit": ("limitSpeed", "speedLimit", "maxSpeed", "limitSpeedMps", "speedMax"),
    "min_minutes": ("startQualifiedTime", "qualifiedTime", "minTime", "minMinutes",
                    "startQualifiedMinutes"),
    "max_minutes": ("endQualifiedTime", "endTimeQualified", "maxTime", "maxMinutes"),
    "step":        ("step", "steps", "stepCount", "totalStep"),
    "step_recursion": ("isStepRecursion", "stepRecursion", "isStepRecursive"),
    "stride":      ("endStride", "limitStride", "strideLimit", "maxStride", "strideMax"),
    "cadence":     ("endLimitStepFrequency", "limitStepFrequency", "stepFrequencyLimit",
                    "maxCadence", "cadenceMax"),
    "face_start":  ("isStartFace", "startFace", "isStartFaceCheck", "needStartFace"),
    "face_end":    ("isEndFace", "endFace", "isEndFaceCheck", "needEndFace"),
    "face_mid":    ("middleFaces", "middleFace", "midFaces", "midwayFaces", "middlePoints"),
    "face_mid_on": ("isMidwayFace", "isMiddleFace", "midFace", "isMidFace"),
    "fence":       ("geofence", "fences", "fenceList", "areaList", "areaFence"),
    "sequence":    ("isSequencePoint", "sequencePoint", "isSequence", "needSequence"),
    "identify":    ("identify", "identifier", "identifyId", "identifyCode"),
}

# ---- 结构探针用的词表（打卡点没有固定路径，只能在树里找）----
_LAT_KEYS = ("latitude", "lat", "lat_", "wd", "y")
_LNG_KEYS = ("longitude", "lng", "lon", "long", "jd", "x")
_RADIUS_KEYS = ("okRadius", "radius", "range", "pointRadius", "arriveRadius", "r")
_NAME_KEYS = ("content", "name", "title", "pointName", "siteName", "address", "remark")

# 强证据：节点自己带这些键 ⇒ 由它说了算（哪怕是 0，也尊重它）
_MUST_FLAGS = ("isMustPoint", "is_must_point", "mustPoint", "isMust", "must",
               "isRequiredPoint", "isClockPoint")

# 弱证据：节点没有标记时，靠"路径像不像打卡点 + 有没有半径"来判
_MUST_HINT = re.compile(r"must|check|punch|sign|clock|campus|site|point|list|"
                        r"必经|打卡|签到", re.I)


# ============================================================ 打卡点
@dataclass
class MustPoint:
    """一个必经打卡点。`lat/lng` 是内部口径（WGS-84），`gcj_*` 是地图口径。"""
    name: str = ""
    lat: float = 0.0
    lng: float = 0.0
    gcj_lat: float = 0.0
    gcj_lng: float = 0.0
    radius: float = 30.0
    evidence: str = ""          # 凭什么认定它是打卡点（排错用）
    source: str = ""            # 它在 bean 里的路径

    def as_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "lat": self.lat, "lng": self.lng,
                "gcj_lat": self.gcj_lat, "gcj_lng": self.gcj_lng,
                "radius": self.radius, "evidence": self.evidence, "source": self.source}


def _lat_lng(node: Dict[str, Any]) -> Optional[Tuple[float, float]]:
    """节点像不像一个经纬度点；是就返回 (lat, lng)。"""
    lat = lng = None
    for k in _LAT_KEYS:
        if k in node:
            lat = _num(node.get(k))
            if lat is not None:
                break
    for k in _LNG_KEYS:
        if k in node:
            lng = _num(node.get(k))
            if lng is not None:
                break
    if lat is None or lng is None:
        return None
    if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lng <= 180.0):
        return None
    if lat == 0.0 and lng == 0.0:               # 0,0 是"没定位"，不是几内亚湾
        return None
    return lat, lng


def _radius(node: Dict[str, Any]) -> Optional[float]:
    for k in _RADIUS_KEYS:
        if k in node:
            n = _num(node.get(k))
            if n is not None and n > 0:
                return n
    return None


def _name(node: Dict[str, Any]) -> str:
    for k in _NAME_KEYS:
        v = node.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _walk(node: Any, path: str = "", depth: int = 0):
    """深度优先遍历，产出 (路径, 节点)。**dict 和 list 都要产出** —— 空数组也有信息量：
    `list: []` 表示"学校明确说没有必经点"，这跟"学校压根没这个字段"是两回事，不能混。
    深度设上限，防畸形数据里的环。
    """
    if depth > 12:
        return
    if isinstance(node, dict):
        yield path, node
        for k, v in node.items():
            yield from _walk(v, "%s.%s" % (path, k) if path else str(k), depth + 1)
    elif isinstance(node, list):
        yield path, node
        for i, v in enumerate(node):
            yield from _walk(v, "%s[%d]" % (path, i), depth + 1)


def _must_evidence(node: Dict[str, Any], path: str) -> Optional[str]:
    """判定"这个点是不是必经打卡点"。**证据不足就返回 None** —— 宁可不认，不能乱认。

    规则（按优先级）：
      ① 节点自己带 `isMustPoint` 之类的标记 ⇒ 完全听它的（`0` 也照 0 算，不兜底）。
         这条挡住的最典型的坑：`campusList[].point[]` 里混着非必经点，它们也有半径。
      ② 节点没有任何标记，但有半径、且路径像打卡点（`list` / `site` / `check` / `campus`…）
         ⇒ 认。老链路 `setting.list` 就是这种形态，它压根没有标记位。
    """
    for k in _MUST_FLAGS:
        if k in node:
            return "%s=%s" % (k, node.get(k)) if _truthy(node.get(k)) else None
    if _radius(node) is not None and _MUST_HINT.search(path or ""):
        return "半径 + 路径含打卡点标记"
    return None


def _point_in_poly(lng: float, lat: float, poly: Sequence[Tuple[float, float]]) -> bool:
    """射线法判点是否在多边形内（`poly` 为 (lng, lat) 序列）。"""
    if len(poly) < 3:
        return False
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        if (y1 > lat) != (y2 > lat):
            xin = (x2 - x1) * (lat - y1) / ((y2 - y1) or 1e-12) + x1
            if lng < xin:
                inside = not inside
    return inside


# 对外名字：plan.py 这类上层模块要判"线在不在围栏里"，不该去碰私有名
point_in_poly = _point_in_poly


def _pick_crs(must_gcj: Sequence[Tuple[float, float]],
              fence_polys: Sequence[Sequence[Tuple[float, float]]]) -> str:
    """判断打卡点到底是 GCJ-02 还是 WGS-84 —— **拿围栏当尺子**。

    围栏是学校画的，打卡点必须落在围栏里（服务器也是这么判的）。所以：
      · 按 GCJ 转 WGS 后落进去的比例 ≥ 原样落进去的比例 ⇒ 它是 GCJ（默认，绝大多数）；
      · 否则说明它本来就是 WGS，再转一次反而会偏出去 ⇒ 原样使用。
    没有围栏就没尺子，只能按项目约定（GCJ）—— 这时候不猜，交给上层记 warning。
    """
    polys = [p for p in fence_polys if len(p) >= 3]
    if not polys or not must_gcj:
        return "gcj02"
    raw_in = sum(1 for lng, lat in must_gcj if any(_point_in_poly(lng, lat, p) for p in polys))
    conv_in = 0
    for lng, lat in must_gcj:
        wlng, wlat = (T.gcj02_to_wgs84(lng, lat) if T else (lng, lat))
        if any(_point_in_poly(wlng, wlat, p) for p in polys):
            conv_in += 1
    return "gcj02" if conv_in >= raw_in else "wgs84"


def _find_must_points(bean: Dict[str, Any], fence_wgs: Sequence[Sequence[Tuple[float, float]]]
                      ) -> Tuple[List[MustPoint], List[str], bool]:
    """在整棵树里找必经打卡点。返回 (点列表, warnings, 是否见过打卡点容器)。"""
    warnings: List[str] = []
    raw_hits: List[Tuple[Dict[str, Any], str, str]] = []      # (节点, 路径, 证据)
    seen_container = False        # 见过打卡点容器（空数组也算 —— "学校说没有"也是信息）
    filled_container = False      # 容器里**确实装了对象**却没认出点 —— 这才是异常
    for path, node in _walk(bean):
        if isinstance(node, list) and path and _MUST_HINT.search(path):
            seen_container = True
            if any(isinstance(it, dict) for it in node):
                filled_container = True
        if not isinstance(node, dict):
            continue
        ll = _lat_lng(node)
        if not ll:
            continue
        ev = _must_evidence(node, path)
        if not ev:
            continue
        raw_hits.append((node, path, ev))

    if not raw_hits:
        # 一条都没认出来，分两种情况 —— 别把正常情况报成异常：
        #   `list: []`（学校明确说没有必经点）⇒ 正常，不吭声；
        #   容器里确实装着对象却一个点都认不出 ⇒ 大概率是字段名没见过，该上覆盖层了。
        if filled_container:
            warnings.append("bean 里有装对象的打卡点容器，但没认出任何带经纬度的点 —— 可能需要覆盖层")
        return [], warnings, seen_container

    # 去重（同一个点可能既在 campusList 又出现在别处）
    dedup: Dict[Tuple[int, int], Tuple[Dict[str, Any], str, str]] = {}
    for node, path, ev in raw_hits:
        lat, lng = _lat_lng(node)  # type: ignore[misc]
        key = (round(lat, 6), round(lng, 6))
        dedup.setdefault(key, (node, path, ev))

    pairs = [(_lat_lng(n), n, p, e) for n, p, e in dedup.values()]  # type: ignore[misc]
    gcj_pts = [(lng, lat) for (lat, lng), *_ in pairs]
    crs = _pick_crs(gcj_pts, fence_wgs)
    if crs != "gcj02":
        warnings.append("打卡点看起来本来就是 WGS-84（按围栏判定），已按原坐标使用，未做 GCJ 转换")

    out: List[MustPoint] = []
    for (lat, lng), node, path, ev in pairs:
        if crs == "gcj02" and T is not None:
            wlng, wlat = T.gcj02_to_wgs84(lng, lat)
        else:
            wlng, wlat = lng, lat
        out.append(MustPoint(name=_name(node), lat=wlat, lng=wlng,
                             gcj_lat=lat, gcj_lng=lng,
                             radius=_radius(node) or 30.0,
                             evidence=ev, source=path))
    return out, warnings, True


def _unwrap(bean: Any) -> Dict[str, Any]:
    """剥掉 `{code, msg, data:{…}}` 信封；`data` 是密文串时原样返回外层，由调用方解。"""
    if not isinstance(bean, dict):
        return {}
    if "data" in bean and isinstance(bean["data"], dict):
        inner = bean["data"]
        if not any(k in bean for k in ("totalRange", "identify")):
            return inner
    return bean


def _fence_polys(fence: Any) -> Tuple[List[List[Dict[str, float]]], List[str]]:
    """把 `geofence` 摊平成 [[{lat,lng},…], …]，并把字符串转成数字。"""
    warnings: List[str] = []
    polys: List[List[Dict[str, float]]] = []
    if not fence:
        return polys, warnings
    if isinstance(fence, str):
        try:
            fence = json.loads(fence)
        except (TypeError, ValueError):
            return polys, ["geofence 是字符串且解析不了，已忽略"]
    if not isinstance(fence, list):
        return polys, ["geofence 不是数组，已忽略"]
    # 退化形态：直接是点数组 [[{lat,lng},…]] 缺一层 → 补一层
    if fence and isinstance(fence[0], dict):
        fence = [fence]
    for poly in fence:
        if not isinstance(poly, list):
            continue
        seg: List[Dict[str, float]] = []
        for p in poly:
            if not isinstance(p, dict):
                continue
            ll = _lat_lng(p)
            if ll:
                seg.append({"lat": ll[0], "lng": ll[1]})
        if len(seg) >= 3:
            polys.append(seg)
    if fence and not polys:
        warnings.append("geofence 有内容但没凑出有效的多边形，已忽略")
    return polys, warnings


# ============================================================ Policy
@dataclass
class Policy:
    """一次跑步的**全部**服务器要求。所有字段都可能缺失 —— 缺失 = 学校没要求/没下发。"""
    school_code: str = ""
    run_type: int = 1
    identify: str = ""

    target_km: Optional[float] = None            # 目标里程
    speed_limit_mps: Optional[float] = None      # 全程均速上限（m/s）
    pace_floor_s_per_km: Optional[float] = None  # 由上限推出的"不能比这更快"
    min_seconds: Optional[float] = None          # 时长门槛（秒）
    max_seconds: Optional[float] = None          # 时长上限（秒，-1 视为不限）
    step: Optional[int] = None                   # 步数门槛
    # 步数门槛是否**递归**（`isStepRecursion=1` 时，超里程按 `step × 实跑/要求` 比例抬）。
    # None = 学校没下发这个字段（按不递归处理，比服务器宽松，只会漏判不会误杀）。
    step_recursion: Optional[bool] = None
    stride_limit_m: Optional[float] = None       # 步幅上限
    cadence_limit_spm: Optional[float] = None    # 步频上限

    face_start: Optional[bool] = None
    face_end: Optional[bool] = None
    face_mid_km: List[float] = field(default_factory=list)
    face_mid_ratios: List[float] = field(default_factory=list)

    fence_raw: Any = None                        # 原样保留（上传时要用原始字符串）
    fence_gcj: List[List[Dict[str, float]]] = field(default_factory=list)
    fence_wgs: List[List[Dict[str, float]]] = field(default_factory=list)

    must_points: List[MustPoint] = field(default_factory=list)
    sequence: Optional[bool] = None
    # 多校区：`campusList` 里每个校区各有一份点表，真机只跑**本人 campusId** 那个校区。
    # 这里把目录留全（界面要让用户看清"有哪几个校区"），`campus_used` 是实际取用的那个。
    campuses: List[Dict[str, Any]] = field(default_factory=list)
    campus_used: Optional[str] = None
    campus_note: str = ""

    run_types_open: Dict[str, bool] = field(default_factory=dict)
    run_window: Dict[str, Any] = field(default_factory=dict)   # 跑步规定时间（开放时段）
    known: set = field(default_factory=set)      # 哪些语义字段见过（覆盖率用）
    unresolved: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict)

    # ---------------------------------------------------------- 覆盖率
    _SLOTS = ("target_km", "speed_limit_mps", "min_seconds", "max_seconds", "step",
              "stride_limit_m", "cadence_limit_spm", "face_start", "face_end",
              "face_mid_ratios", "fence_gcj", "must_points", "sequence", "identify",
              "run_window")

    def coverage(self) -> Tuple[int, int, List[str]]:
        """(认出了几项, 共几项, 缺哪几项)。给界面做「本次策略 12/14」用。"""
        known = set(self.known)
        missing = [s for s in self._SLOTS if s not in known]
        return len(self._SLOTS) - len(missing), len(self._SLOTS), missing

    # ---------------------------------------------------------- 人话
    def describe(self) -> List[str]:
        """一句话一条，直接往界面上贴。"""
        out: List[str] = []
        if self.target_km:
            out.append("目标 %.2f km" % self.target_km)
        if self.speed_limit_mps:
            pace = _fmt_pace(self.pace_floor_s_per_km)
            out.append("均速上限 %.2f m/s（不能快于 %s）" % (self.speed_limit_mps, pace))
        if self.min_seconds:
            out.append("时长不少于 %.0f 分钟" % (self.min_seconds / 60.0))
        if self.max_seconds:
            out.append("时长不超过 %.0f 分钟" % (self.max_seconds / 60.0))
        if self.step:
            out.append("步数不少于 %d 步" % self.step)
        faces = []
        if self.face_start:
            faces.append("开始")
        if self.face_mid_ratios:
            faces.append("中途 ×%d" % len(self.face_mid_ratios))
        if self.face_end:
            faces.append("结束")
        out.append("人脸打卡：%s" % ("、".join(faces) if faces else "免打卡"))
        if self.must_points:
            out.append("必经打卡点 %d 个%s" % (
                len(self.must_points),
                ("（%s 校区）" % self.campus_used) if self.campus_used else ""))
        else:
            out.append("必经打卡点：学校未下发")
        if self.fence_gcj:
            out.append("有效区域 %d 块" % len(self.fence_gcj))
        if self.sequence is True:
            out.append("需按顺序打卡")
        for line in self.run_window.get("describe") or []:
            out.append(line)
        return out

    def as_dict(self) -> Dict[str, Any]:
        """JSON 安全（给前端 / 日志）。"""
        known = sorted(self.known)
        n_ok, n_all, missing = self.coverage()
        return {
            "school_code": self.school_code, "run_type": self.run_type,
            "identify": self.identify,
            "target_km": self.target_km,
            "speed_limit_mps": self.speed_limit_mps,
            "pace_floor_s_per_km": self.pace_floor_s_per_km,
            "min_seconds": self.min_seconds, "max_seconds": self.max_seconds,
            "step": self.step, "stride_limit_m": self.stride_limit_m,
            "step_recursion": self.step_recursion,
            "cadence_limit_spm": self.cadence_limit_spm,
            "face_start": self.face_start, "face_end": self.face_end,
            "face_mid_km": list(self.face_mid_km),
            "face_mid_ratios": list(self.face_mid_ratios),
            "fence_gcj": self.fence_gcj, "fence_wgs": self.fence_wgs,
            "must_points": [p.as_dict() for p in self.must_points],
            "sequence": self.sequence,
            "campuses": list(self.campuses),
            "campus_used": self.campus_used,
            "campus_note": self.campus_note,
            "run_window": dict(self.run_window),
            "run_types_open": dict(self.run_types_open),
            "coverage": {"known": n_ok, "total": n_all, "missing": missing, "known_keys": known},
            "unresolved": list(self.unresolved),
            "warnings": list(self.warnings),
            "describe": self.describe(),
        }


def _fmt_pace(sec_per_km: Optional[float]) -> str:
    if not sec_per_km:
        return "—"
    m, s = divmod(int(round(sec_per_km)), 60)
    return "%d′%02d″/km" % (m, s)


# ============================================================ 跑步规定时间
_WIN_START_KEYS = ("runStartTime", "startRunTime", "runTimeStart", "openTime",
                   "exerciseStartTime", "startTimeStr", "beginTime")
_WIN_END_KEYS = ("runEndTime", "endRunTime", "runTimeEnd", "closeTime",
                 "exerciseEndTime", "endTimeStr", "finishTime")


def _parse_hhmm(v: Any) -> Optional[int]:
    """把 `"06:30"` / `"6:30"` / `630` / `6` 解析成「当天第几分钟」；认不出返回 None。

    体适能各校的时段字段写法很杂（有的发 `"06:00-22:00"` 一整串、有的发两个键、
    有的只发小时数）。这里只做**保守解析**：认得出就用，认不出就说"未下发"，
    绝不猜一个时段出来（猜错会让人在禁跑时段被服务器判异常）。
    """
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        n = float(v)
        if 0 <= n <= 24:                       # 只给了小时
            return int(round(n * 60)) % (24 * 60)
        if 100 <= n <= 2359:                   # 630 / 2230 这种紧凑写法
            h, m = int(n) // 100, int(n) % 100
            if 0 <= h <= 23 and 0 <= m <= 59:
                return h * 60 + m
        return None
    s = str(v).strip()
    if not s:
        return None
    m = re.match(r"^(\d{1,2})\s*[:：]\s*(\d{1,2})", s)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if 0 <= h <= 23 and 0 <= mi <= 59:
            return h * 60 + mi
        return None
    m = re.match(r"^(\d{1,2})\s*(?:点|时)", s)
    if m:
        h = int(m.group(1))
        if 0 <= h <= 23:
            return h * 60
    try:
        return _parse_hhmm(float(s))
    except (TypeError, ValueError):
        return None


def _run_window(bean: Dict[str, Any]) -> Dict[str, Any]:
    """识别「跑步规定时间」（学校允许开跑的时段）。认不出就返回空 dict。"""
    sv, sk = _first(bean, _WIN_START_KEYS)
    ev, ek = _first(bean, _WIN_END_KEYS)
    # 一整串 "06:00-22:00" 的写法
    if sk and isinstance(sv, str) and ("-" in sv or "~" in sv) and not ek:
        a, _, c = sv.replace("~", "-").partition("-")
        sv, ev = a, c
    s_min, e_min = _parse_hhmm(sv), _parse_hhmm(ev)
    if s_min is None or e_min is None:
        return {}
    out: Dict[str, Any] = {"start_min": s_min, "end_min": e_min,
                           "start": "%02d:%02d" % (s_min // 60, s_min % 60),
                           "end": "%02d:%02d" % (e_min // 60, e_min % 60),
                           "keys": [sk, ek]}
    out["describe"] = ["跑步时段 %s–%s" % (out["start"], out["end"])]
    return out


# ============================================================ 多校区
def _campus_index(bean: Dict[str, Any]) -> List[Dict[str, Any]]:
    """列出 `campusList` 里的校区目录：[{id, name, count}]（只描述，不改数据）。"""
    out: List[Dict[str, Any]] = []
    for i, c in enumerate(bean.get("campusList") or []):
        if not isinstance(c, dict):
            continue
        cid = c.get("id")
        if cid in (None, ""):
            cid = c.get("campusId")
        pts = c.get("point") or []
        out.append({"id": "" if cid in (None, "") else str(cid),
                    "name": str(c.get("campusName") or c.get("name") or "校区 %d" % (i + 1)),
                    "count": len(pts) if isinstance(pts, list) else 0})
    return out


def _filter_by_campus(bean: Dict[str, Any], campus_id: Optional[str],
                      campus_name: Optional[str] = None
                      ) -> Tuple[Dict[str, Any], List[Dict[str, Any]], Optional[str], str]:
    """按"本人校区"裁剪 `campusList` 的点表 —— 返回 (bean, 目录, 实际取用, 说明)。

    为什么必须这么做：`campusList` 是**学校全量**（每个校区一份点表），而一次跑步只可能
    在一个校区里完成。把别的校区的必经点也钉进轨迹，等于要求你从广州跑到肇庆 ——
    生成出来的线要么横跨半个省（越界），要么怎么绕都到不了（reachRange=0）。

    参考实现（`tsnRunServer.startRun`）用登录用户信息里的 `campusId` 选表：
        campusIdPointDict[campusId] → pointList
    这里同口径，并且**只在能确定时裁剪**：给不出 id、或 id 不在目录里，就保留全部
    （`note` 里说清楚），绝不因为"猜错校区"把点表清空。
    """
    campuses = _campus_index(bean)
    if not campuses:
        return bean, campuses, None, ""
    want_id = str(campus_id).strip() if campus_id not in (None, "") else ""
    want_name = str(campus_name or "").strip()
    if len(campuses) <= 1:
        only = campuses[0]
        return bean, campuses, (only["id"] or only["name"]), ""
    hit = None
    if want_id:
        hit = next((c for c in campuses if c["id"] == want_id), None)
    if hit is None and want_name:
        hit = next((c for c in campuses if c["name"] == want_name), None)
    if hit is None:
        return bean, campuses, None, ("学校下发了 %d 个校区的打卡点，但没拿到本人校区"
                                     "（campusId=%s）—— 已合并全部校区的点" %
                                     (len(campuses), want_id or "缺"))
    b = dict(bean)
    kept: List[Dict[str, Any]] = []
    for i, c in enumerate(bean.get("campusList") or []):
        if not isinstance(c, dict):
            continue
        cid = c.get("id")
        if cid in (None, ""):
            cid = c.get("campusId")
        cid = "" if cid in (None, "") else str(cid)
        nm = str(c.get("campusName") or c.get("name") or "校区 %d" % (i + 1))
        cc = dict(c)
        if not (cid == hit["id"] and (hit["id"] or nm == hit["name"])):
            cc["point"] = []          # 别的校区：点表清空（保留目录信息）
        kept.append(cc)
    b["campusList"] = kept
    # campusList 已给出**精确**点表 ⇒ 老链路的 `list`（若有）是同一批点的另一种形态，
    # 留着只会把别的校区的点又带回来。
    if b.get("list"):
        b["list"] = []
    return b, campuses, (hit["id"] or hit["name"]), ""


# ============================================================ 主入口
def parse(bean: Any, *, school_code: str = "", run_type: int = 1,
          run_types: Optional[Dict[str, bool]] = None,
          campus_id: Optional[str] = None, campus_name: Optional[str] = None,
          ) -> Policy:
    """服务器 bean → `Policy`。**这是本模块唯一的对外入口。**

    不抛异常：任何解析失败都降级成"这一项未知"，并记进 `warnings`。
    执行层拿到 Policy 后，只该看"有没有值"，不该看"是哪所学校"。
    """
    b = _unwrap(bean)
    p = Policy(school_code=school_code, run_type=run_type, raw=b)
    if not isinstance(b, dict) or not b:
        p.warnings.append("bean 为空或不是对象 —— 可能未登录 / 服务器拒绝 / 今日不可跑")
        p.unresolved = [s for s in Policy._SLOTS]
        return p

    # ---------- 里程 ----------
    v, k = _first(b, _ALIASES["target"])
    if k:
        p.known.add("target_km")
        p.target_km = _normalize_km(v)
        if p.target_km is None:
            p.warnings.append("目标里程 %r 解析不出正数" % (v,))

    # ---------- 限速 → 配速下限 ----------
    v, k = _first(b, _ALIASES["speed_limit"])
    if k:
        p.known.add("speed_limit_mps")
        p.speed_limit_mps = _num(v)
        if p.speed_limit_mps and p.speed_limit_mps > 0:
            p.pace_floor_s_per_km = 1000.0 / p.speed_limit_mps
        else:
            p.warnings.append("limitSpeed=%r 不是正数，按「不限速」处理" % (v,))

    # ---------- 时长 ----------
    v, k = _first(b, _ALIASES["min_minutes"])
    if k:
        p.known.add("min_seconds")
        m = _num(v)
        p.min_seconds = m * 60.0 if m and m > 0 else None
    v, k = _first(b, _ALIASES["max_minutes"])
    if k:
        p.known.add("max_seconds")
        m = _num(v)
        if m is None or m < 0:                   # -1 = 不限（真机常见）
            p.max_seconds = None
        else:
            p.max_seconds = m * 60.0 if m > 0 else None

    # ---------- 步数 / 步幅 / 步频 ----------
    v, k = _first(b, _ALIASES["step"])
    if k:
        p.known.add("step")
        n = _num(v)
        p.step = int(n) if n and n > 0 else None
    v, k = _first(b, _ALIASES["step_recursion"])
    if k:
        # 不记进 `known`：`_SLOTS` 里没有它，记了会让覆盖率的分母对不上。
        # 但值必须读出来 —— 服务端会按它递归抬步数门槛，本地复核得同口径。
        p.step_recursion = _truthy(v)
    v, k = _first(b, _ALIASES["stride"])
    if k:
        p.known.add("stride_limit_m")
        n = _num(v)
        p.stride_limit_m = n if n and n > 0 else None
    v, k = _first(b, _ALIASES["cadence"])
    if k:
        p.known.add("cadence_limit_spm")
        n = _num(v)
        p.cadence_limit_spm = n if n and n > 0 else None

    # ---------- 人脸 ----------
    v, k = _first(b, _ALIASES["face_start"])
    if k:
        p.known.add("face_start")
        p.face_start = _truthy(v)
    v, k = _first(b, _ALIASES["face_end"])
    if k:
        p.known.add("face_end")
        p.face_end = _truthy(v)

    mids, k = _first(b, _ALIASES["face_mid"])
    mid_on, k2 = _first(b, _ALIASES["face_mid_on"])
    if k:
        p.known.add("face_mid_ratios")
        if isinstance(mids, str):
            try:
                mids = json.loads(mids)
            except (TypeError, ValueError):
                mids = []
        items = mids if isinstance(mids, list) else ([mids] if mids is not None else [])
        km_list: List[float] = []
        for it in items:
            if isinstance(it, dict):             # 有的学校会把整个人脸点（含时间/坐标）发下来
                km = _normalize_km(it.get("distance") or it.get("km") or it.get("range"))
                if km:
                    km_list.append(km)
                continue
            km = _normalize_km(it)
            if km:
                km_list.append(km)
        p.face_mid_km = km_list
        if km_list and p.target_km:
            ratios = []
            for km in km_list:
                r = km / p.target_km
                if r <= 0 or r >= 1:
                    p.warnings.append("中途人脸位置 %.3f km 超出目标 %.2f km，已夹到边界"
                                      % (km, p.target_km))
                    r = min(max(r, 0.01), 0.99)
                ratios.append(round(r, 4))
            p.face_mid_ratios = ratios
        elif km_list:
            p.warnings.append("有中途人脸位置但目标里程未知，换算不了比例 —— 已忽略")
    elif _truthy(mid_on):
        p.known.add("face_mid_ratios")
        p.face_mid_ratios = [0.5]
        p.warnings.append("学校只说「要中途人脸」但没给位置，按 50%% 处打一次")

    # ---------- 跑步规定时间 ----------
    p.run_window = _run_window(b)
    if p.run_window:
        p.known.add("run_window")

    # ---------- 围栏 ----------
    fence, k = _first(b, _ALIASES["fence"])
    if k:
        p.known.add("fence_gcj")
        p.fence_raw = fence
        polys, fw = _fence_polys(fence)
        p.fence_gcj = polys
        p.warnings.extend(fw)
        if polys and T is not None:
            for poly in polys:
                p.fence_wgs.append([{"lat": T.gcj02_to_wgs84(q["lng"], q["lat"])[1],
                                     "lng": T.gcj02_to_wgs84(q["lng"], q["lat"])[0]}
                                    for q in poly])
        elif polys:
            p.fence_wgs = [list(poly) for poly in polys]

    # ---------- 打卡点（多校区：先按本人校区裁剪）----------
    b, _campuses, _campus_used, _campus_note = _filter_by_campus(b, campus_id, campus_name)
    p.campuses = _campuses
    p.campus_used = _campus_used
    p.campus_note = _campus_note
    if _campus_note:
        p.warnings.append(_campus_note)
    fence_flat = [[(q["lng"], q["lat"]) for q in poly] for poly in p.fence_wgs]
    pts, mw, seen = _find_must_points(b, fence_flat)
    p.warnings.extend(mw)
    if pts or seen:
        p.known.add("must_points")
    p.must_points = pts

    # ---------- 顺序 / 标识 ----------
    v, k = _first(b, _ALIASES["sequence"])
    if k:
        p.known.add("sequence")
        p.sequence = _truthy(v)
    v, k = _first(b, _ALIASES["identify"])
    if k:
        p.known.add("identify")
        p.identify = str(v)

    # ---------- 跑步类型开放情况（由调用方探到再喂进来）----------
    if run_types:
        p.run_types_open = {str(k2): bool(v2) for k2, v2 in run_types.items()}

    n_ok, n_all, missing = p.coverage()
    p.unresolved = [m for m in missing if m != "identify"]   # identify 缺多半是未登录
    return p

# -*- coding: utf-8 -*-
"""体适能 · 最新版 · 抓包旁路启动器（不修改项目任何代码）

启动工作台之前，把 `v2client.V2Client._req` 换成"先转发、再落盘"的包装。
Python 模块是单例，所以 `server.py` 里 `import v2client as V2C` 拿到的都是同一个类，
整个进程（登录/配置/开跑/人脸/上传）的每个请求都会被记录。

产物：抓包工具/captures/<序号>_<步骤>.json
"""
from __future__ import annotations

import json
import os
import sys
import time

# ------------------------------------------------------------------ 路径
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 体适能最新版/
CODE = os.path.join(PROJ, "tsn-auto-run-latest")
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "capture", "captures")
os.makedirs(OUT, exist_ok=True)
if CODE not in sys.path:
    sys.path.insert(0, CODE)

_INDEX = {"n": 0}


def _tag_of(path: str) -> str:
    p = (path or "").strip("/").split("?")[0]
    last = p.split("/")[-1] or "root"
    return "".join(c for c in last if c.isalnum() or c in "_-")[:40] or "root"


def _dump(record) -> None:
    fn = record["_file"]
    record = {k: v for k, v in record.items() if not k.startswith("_")}
    try:
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)
        print("[cap] %s  (%.0f KB)" % (os.path.basename(fn), os.path.getsize(fn) / 1024.0),
              flush=True)
    except Exception as e:                                # noqa: BLE001
        print("[cap] 写盘失败 %r" % e, flush=True)


def install_patch() -> bool:
    import v2client as V2C
    if getattr(V2C.V2Client._req, "_tsn_cap", False):
        return True
    orig = V2C.V2Client._req

    def _req(self, method, path, *, form=None, query=None, headers=None,
             body=None, ctype=None):
        idx = _INDEX["n"] + 1
        _INDEX["n"] = idx
        record = {
            "_file": os.path.join(OUT, "%02d_%s.json" % (idx, _tag_of(path))),
            "captured_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "base": getattr(self, "base", None),
            "method": method,
            "path": path,
            "query": query,
            "form": form,
            "headers": headers,
            "body_len": len(body) if isinstance(body, (bytes, str)) else None,
        }
        t0 = time.time()
        try:
            resp = orig(self, method, path, form=form, query=query,
                        headers=headers, body=body, ctype=ctype)
        except Exception as e:                            # noqa: BLE001
            record["ms"] = int((time.time() - t0) * 1000)
            record["error"] = repr(e)
            try:
                record["error_payload"] = list(e.args)[1:]
            except Exception:                             # noqa: BLE001
                pass
            _dump(record)
            raise
        record["ms"] = int((time.time() - t0) * 1000)
        record["response"] = resp
        _dump(record)
        return resp

    _req._tsn_cap = True                                  # type: ignore[attr-defined]
    V2C.V2Client._req = _req
    return True


def main() -> int:
    ok = install_patch()
    print("[cap] v2client._req 已包装：%s" % ("是" if ok else "否"), flush=True)
    print("[cap] 报文目录：%s" % OUT, flush=True)
    try:
        import app as A
        return int(A.main())
    except SystemExit as e:
        return int(e.code or 0)


if __name__ == "__main__":
    sys.exit(main())
# -*- coding: utf-8 -*-
"""plan.py —— 把「服务器策略 + 你画的线」变成「一次可以开跑的计划」。

分工
----
* `policy.py`：读懂服务器要什么（Policy）
* `plan.py`：**把 Policy 和折线凑成一份能跑的计划**，并在开跑前告诉你哪里会不合格
* `tracklib.py`：真正生成轨迹（不认识 Policy，只认参数）

本文件不含任何学校名。换学校只会改变 Policy 里的值，不会改变这里的代码。

两道自检
--------
1. **开跑前** `build()`：折线够不够、里程目标多少、计划配速会不会超速/超时、
   打卡点钉没钉进去、整条线在不在围栏里。这些都是**静态**判断，不用真的跑一遍。
2. **生成后** `verify()`：拿真实生成的轨迹复核里程 / 时长 / 限速 / 步幅步频 / 围栏 / 打卡点覆盖 / 顺序。

为什么两道都要
--------------
静态自检能挡住"线画错了"（越界、漏点），生成后自检能挡住"参数没算对"
（配速算快了、时长不够）。只做前者会漏掉生成器本身的偏差，只做后者则要等生成完才知道。
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import policy as P
import tracklib as T

# 没拿到服务器目标里程时的兜底（真机有效区间 0.8–3.0 km 的中间值）
DEFAULT_TARGET_KM = 2.5
# 计划配速的基线区间（秒/公里）：4′30″–5′30″。
# 参考实现（tsnRunServer）用的是 `runKiloMeter * uniform(4.5, 5.5) * 60`，
# 即 4′30″–5′30″/km —— 真人慢跑就在这个带宽里；**每次抽一个**比固定 5′30″ 更像人，
# 也让「同一账号连续两次跑步配速一模一样」这种指纹消失。
PACE_BASE_RANGE = (270.0, 330.0)
DEFAULT_PACE = 330.0
# 计划配速相对"限速换算出的下限"再留的余量（3%），免得贴线被判超速
PACE_MARGIN = 0.03
# 时长上下限再各留 2% 余量：生成器的速度抖动会让实际运动时长偏离 `目标×配速` 1–2%，
# 贴线就会翻到不合格那一侧（下限差 3 秒 = 整条记录作废）。
TIME_MARGIN = 0.02
# 起跑延迟（秒）：参考实现取 14–20 s（`startTime + randint(14,20)*1000`）。
START_DELAY_S = (14.0, 20.0)
# 围栏安全边距（米）：内部 WGS ↔ 上传 GCJ 的往返 + GPS 噪声会吃掉一两米，
# 贴着围栏线跑的点上传后可能被判"围栏外"。留 2.5 m 余量。
FENCE_MARGIN_M = 2.5
# 步频（步/分）再留 2% 余量：`_pick_stride` 算的步频是**理论均速**下的值（里程/步幅
# /计划用时），而生成器的实际步频由「实际里程 / 步幅 / 实际运动时长」聚合而来 ——
# 起步 4 s 不落点、收尾减速段、GPS 抖动都会让它偏离理论值（实测 1000 轮里最大
# ±0.75%）。贴线就会翻到不合格那一侧：第 906 轮理论 179.5 步/分、实际 180.4，
# 超出上限 180 的 0.4 步 ⇒ 整条记录作废。留 2% 等价于步幅再多压 2%。
CADENCE_MARGIN = 0.02
# 「按顺序打卡」预检的两个口径参数 —— 必须与生成器/真机对齐，否则会出现
# 「开跑前说能按顺序过、跑完却判顺序错」这种最坏的情况（1000 轮第 #369 轮）。
#   · `SAMPLE_SPACING_M`：落点间距。真机 1 s 一个点、配速 3.3 m/s ⇒ ≈3.3 m。
#     判定"有没有进圈"只发生在落点上，按 1.5 m 精细几何算会过度乐观。
#   · `HIT_SHRINK_M`：判定半径的收缩量。真机 GPS 噪声 ±3 m，贴着圈边(49.2/50 m)
#     会被算成命中、实际却可能漏掉；收缩后判"稳稳进圈"才是真能打卡。
SAMPLE_SPACING_M = 3.3
HIT_SHRINK_M = 8.0
# 相邻两个必打点**进圈位置**至少要隔这么多米路径。隔得更近时，GPS 噪声 ±3 m
# 加起步跳过 4 s（约 13 m）就足以让两者翻序（1000 轮第 #934 轮：只差 23 m 就翻过）。
HIT_ORDER_GAP_M = 40.0
# 「这条线上没进这个点的圈」的哨兵索引。**不要用 `10**9` 这类大整数**：
# 它既可能撞上真实索引（路径极长时），含义也不如一个具名常量清楚。
INF_IDX = 1 << 30

# ============================================================ 闸门策略（B 方案）
# 用户口径（2026-11-13）：「我只需要做到，能按照我在前端画的路线跑步，选的配速和公里数
# 开跑就行，其他无所谓」+「学校打卡点没有顺序要求」。
#
# 于是把自检拆成两档：
#   · **硬闸（must）** = 这条记录**物理上跑不出来**，或跑出来必然是错的数（里程/时长/
#     限速/步幅步频、围栏、贴边）。留着 —— 它们拦的不是"线画得不好"，是"根本跑不成"。
#   · **提示（soft）** = "线可以更好"的建议（打卡顺序、钉点代价、必打点覆盖超标）。
#     降级后界面照样把它标黄列出来，但**不再阻止开跑**。
#
# 改动只影响"要不要拦"，不影响"算不算" —— 检查项本身一行没删，结论照旧回传，
# 界面仍然能看到哪里不理想。
#
# 要恢复"全部都是硬闸"的老行为：把 `SOFT_CHECKS` 清空即可（`SOFT_CHECKS = frozenset()`）。
SOFT_CHECKS = frozenset((
    "打卡顺序",       # 学校不下发 isSequencePoint=1 时本来就跳过；下发时降为提示
    "钉点代价",       # 线被拉长了，形状可能不像你画的 —— 提示你改线，不拦
    "必打点覆盖",     # 为了穿点多跑了 50%+ —— 提示，不拦
))
# ⚠️ **不在这个集合里的都还是硬闸**，尤其是「必经点顺序冲突」（点压根没被钉进去 ⇒
#    必然漏点）、「必经打卡点」「打卡时刻表」「有效区域」「起终点」「步幅步频」。
#    这几项一旦降级，就会出现"开跑前全绿、跑完判不合格"——B 方案只降"线可以更好"，
#    绝不降"这条记录会作废"。


def _soft(name: str) -> str:
    """按名字决定这条自检的级别。硬闸保持 `must`，其余降为 `soft`。"""
    return "soft" if name in SOFT_CHECKS else "must"


# ============================================================ 自检项
@dataclass
class Check:
    """一条自检结论。`ok=None` 表示"不适用/学校没这项要求"，界面上灰着显示。"""
    name: str
    ok: Optional[bool]
    detail: str = ""
    level: str = "must"          # must = 不合格就别跑；soft = 提醒，可继续

    def as_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "ok": self.ok, "detail": self.detail, "level": self.level}


@dataclass
class Plan:
    """一次开跑计划：参数 + 自检 + 说明。"""
    params: Dict[str, Any] = field(default_factory=dict)
    path: List[List[float]] = field(default_factory=list)      # 钉过点的折线（WGS，[[lng,lat]])
    checks: List[Check] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    must_report: List[Dict[str, Any]] = field(default_factory=list)
    start_delay_s: float = 0.0
    server_start_ms: Optional[int] = None
    actual_start_ms: Optional[int] = None
    # 学校要求的最低里程 vs 这次实际要跑的里程。两者在"界面上多跑一点"时不同，
    # 界面得把这件事说清楚（否则用户以为我们擅自改了他的设置）。
    require_km: Optional[float] = None
    run_km: Optional[float] = None

    @property
    def ok(self) -> bool:
        """所有 must 级自检都过 → 可以直接开跑。"""
        return all(c.ok is not False for c in self.checks if c.level == "must")

    def failures(self) -> List[Check]:
        return [c for c in self.checks if c.ok is False]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "params": self.params,
            "path": self.path,
            "checks": [c.as_dict() for c in self.checks],
            "notes": self.notes,
            "must_report": self.must_report,
        }


# ============================================================ 几何
def _xy(lng: float, lat: float, lat0: float) -> Tuple[float, float]:
    """局部平面近似（米）。在几百米尺度上误差可以忽略，够用来算"点到线段距离"。"""
    return (lng * 111320.0 * math.cos(math.radians(lat0)), lat * 110540.0)


def _seg_dist_m(lat: float, lng: float, a: Sequence[float], b: Sequence[float]) -> float:
    """点 (lat,lng) 到线段 a–b 的最短距离（米）。a/b 为 [lng,lat]。"""
    ax, ay = _xy(a[0], a[1], lat)
    bx, by = _xy(b[0], b[1], lat)
    px, py = _xy(lng, lat, lat)
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return math.hypot(px - ax, py - ay)
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _dist_to_ring(lng: float, lat: float, poly: Sequence[Dict[str, float]]) -> float:
    """点到多边形**边界**的最短距离（米，局部平面近似）。"""
    k = 111320.0 * math.cos(math.radians(lat))
    px, py = lng * k, lat * 110540.0
    best = float("inf")
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        ax, ay = float(a["lng"]) * k, float(a["lat"]) * 110540.0
        bx, by = float(b["lng"]) * k, float(b["lat"]) * 110540.0
        dx, dy = bx - ax, by - ay
        if dx == 0 and dy == 0:
            d = math.hypot(px - ax, py - ay)
        else:
            t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
            t = max(0.0, min(1.0, t))
            d = math.hypot(px - (ax + t * dx), py - (ay + t * dy))
        if d < best:
            best = d
    return best


def _fence_verdict(lng: float, lat: float,
                   polys: Sequence[Sequence[Dict[str, float]]],
                   margin_m: float = 0.0) -> Tuple[bool, float]:
    """点是否**稳稳地**落在围栏内 ⇒ (ok, 到最近边界的距离)。

    `margin_m > 0` 时要求"离边界至少这么远" —— 因为上传的是 GCJ 坐标，
    而内部几何是 WGS，来回换算 + GPS 噪声会吃掉一两米；贴着线跑的点上传后就出界了。
    """
    best = float("inf")
    for poly in polys:
        pts = [(float(q["lng"]), float(q["lat"])) for q in poly]
        if not P.point_in_poly(lng, lat, pts):
            continue
        d = _dist_to_ring(lng, lat, poly)
        best = min(best, d)
        if d >= margin_m:
            return True, d
    return False, best


def _densify(path: Sequence[Sequence[float]], step_m: float = 10.0) -> List[Tuple[float, float]]:
    """把折线按约 `step_m` 加密成点列（用于"整条线在不在围栏里"这类静态判断）。"""
    out: List[Tuple[float, float]] = []
    for i in range(len(path) - 1):
        a, b = path[i], path[i + 1]
        seg = T.haversine(a[1], a[0], b[1], b[0])
        n = max(1, int(math.ceil(seg / max(step_m, 1.0))))
        for k in range(n):
            t = k / float(n)
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    if path:
        out.append((path[-1][0], path[-1][1]))
    return out


def _seg_index_near(path: Sequence[Sequence[float]], mp) -> int:
    """点 `mp` 在折线上最近的**段索引**（0..len-2）。"""
    best_i, best_d = 0, None
    for i in range(len(path) - 1):
        d = _seg_dist_m(mp.lat, mp.lng, path[i], path[i + 1])
        if best_d is None or d < best_d:
            best_d, best_i = d, i
    return best_i


def align_path_to_sequence(path: Sequence[Sequence[float]],
                           must_points: Sequence[P.MustPoint],
                           ) -> Tuple[List[List[float]], str]:
    """按「必须按顺序打卡」把折线的**起点/方向**摆正，返回 (新折线, 说明)。

    为什么需要这一步：闭环轨迹的起点是任意的。若起点正好落在「点2 与 点3 之间」，
    那么第一圈会**先**经过点3，再点1、点2 —— 顺序永远错。这不是"钉点没钉好"，
    而是"起跑位置选错了"。修法只有两种，这里都做：

      · 必打点的几何顺序与绕行方向**相反** ⇒ 把整条线反过来走（`reversed`）；
      · 方向一致但起点不对 ⇒ 把环**旋转**到"第一个必打点之前"。

    非闭合折线（用户手画的 A→B）只做方向判断，不做旋转。
    """
    pts = [[float(p[0]), float(p[1])] for p in path]
    if len(pts) < 3 or len(must_points) < 2:
        return pts, ""
    idxs = [_seg_index_near(pts, mp) for mp in must_points]
    inc = sum(1 for a, b in zip(idxs, idxs[1:]) if b > a)
    dec = (len(idxs) - 1) - inc
    note = ""
    if dec > inc:
        pts = list(reversed(pts))
        note = "已把轨迹方向反过来走（学校下发的打卡顺序与画的线方向相反）"
        idxs = [len(pts) - 2 - i for i in idxs]
    # 闭合环才旋转（首尾同点，误差 20 m 内算闭合）
    closed = T.haversine(pts[0][1], pts[0][0], pts[-1][1], pts[-1][0]) < 20.0
    if closed and len(pts) >= 6:
        k = idxs[0] % (len(pts) - 1)
        if k > 0:
            body = pts[:-1]                     # 去掉重复的闭合点
            n = len(body)
            new = body[k:] + body[:k] + [body[k]]
            pts = [list(p) for p in new]
            note = (note + "；" if note else "") + \
                "已把起点挪到第 1 个必经点之前（原起点在它后面，第一圈会先打到后面的点）"
        # ⚠️ **起点自己不能落在任何必打点的圈里**（1000 轮第 #404 轮）：
        #    把环转到"第 1 个点之前"之后，新的起点可能正好压在**后面某个点**的圈内
        #    （实测起点离点2 只有 42.9 m，而半径 50 m）—— 那样第一个落点就命中了它，
        #    跑完按真实落点重排必然翻序。这里往后挪几个点，找个"谁都不沾"的起点。
        pts = _skip_start_out_of_circles(pts, must_points)
    return pts, note


def _skip_start_out_of_circles(path: List[List[float]],
                               must_points: Sequence[P.MustPoint]) -> List[List[float]]:
    """把闭合环的起点沿环往后挪，直到它不落在任何必打点的判定圈内。

    挪不动（整条环都被圈覆盖）就原样返回 —— 那种线本来就该被 `_seq_check` 拦下。
    """
    if len(path) < 6 or not must_points:
        return path
    body = path[:-1]
    n = len(body)
    if n < 4:
        return path

    def _clear(p: Sequence[float]) -> bool:
        # 留一点余量：起点贴着圈边时，GPS 噪声一样能把第一个点抖进圈里
        for mp in must_points:
            if T.haversine(mp.lat, mp.lng, p[1], p[0]) <= float(mp.radius) + HIT_SHRINK_M:
                return False
        return True

    if _clear(body[0]):
        return path
    for k in range(1, n):
        if _clear(body[k]):
            return [list(p) for p in (body[k:] + body[:k] + [body[k]])]
    return path


def inject_must_points(path: Sequence[Sequence[float]],
                       must_points: Sequence[P.MustPoint],
                       *, sequence: bool = False,
                       ) -> Tuple[List[List[float]], List[Dict[str, Any]]]:
    """把必经打卡点**钉进**折线，返回 (新折线, 每个点的处置报告)。

    两条规则，缺一条都会出问题：
      ① **已经够近就不动它**。点离线不到半径一半时，硬钉进去只会让线无谓地拐一下，
         反而把里程和轨迹形态搞乱。这种情况按"顺路"处理。
      ② **用一个点替换一段**。把打卡点作为新顶点插到最近线段上（A→M→B），而不是把整条线
         平移到点上 —— 平移会改变所有点的相对关系，越往后越歪。

    插入顺序：默认**从远到近**（远的先钉，近的再钉时不会把远的投影位置挤跑）。
    但学校要求 `isSequencePoint=1`（必须按**下发顺序**打卡）时，这个策略会直接踩坑：
    「远到近」是按几何排的，插完以后实际经过顺序常常与下发顺序相反 —— 首轮 1000 次回归里
    23/30 轮就是这么挂的。所以 `sequence=True` 时改成**按下发顺序、只允许往后找线段**，
    保证「先经过 point[0]，再 point[1]…」。
    """
    pts = [[float(p[0]), float(p[1])] for p in path]
    report: List[Dict[str, Any]] = []
    if not pts or len(pts) < 2 or not must_points:
        return pts, report

    if sequence:
        cursor = 0                       # 只能插在 cursor 之后的线段上
        for mp in must_points:
            item = {"name": mp.name or "未命名点", "radius": mp.radius, "action": ""}
            best_i, best_d = None, None
            for i in range(cursor, len(pts) - 1):
                d = _seg_dist_m(mp.lat, mp.lng, pts[i], pts[i + 1])
                if best_d is None or d < best_d:
                    best_d, best_i = d, i
            item["dist_before"] = round(best_d if best_d is not None else -1.0, 1)
            if best_i is None:
                # cursor 已经到线尾，而这个点还排在后面 ⇒ 想按顺序穿过它就得**再绕一圈**。
                # 与其生成一条"跑到第二圈才打这个点"的记录（里程翻倍、形状难看），
                # 不如在这里说清楚：换方向 / 重画线。
                item["action"] = "无可用线段（顺序冲突）"
                item["failed"] = True
                report.append(item)
                continue
            # ⚠️ 顺序模式下**不做**"够近就不动"的优化：那个优化会让点留在它**原来**的
            # 几何位置上，而那个位置可能排在后面几个点之后 ⇒ 第一圈先打到顺序靠后的点
            # （首轮回归里 3 个点出现 [0,2,1] 就是这么来的）。这里一律显式插入，
            # 插入位置随 cursor 单调后移，顺序才是真的。
            pts.insert(best_i + 1, [float(mp.lng), float(mp.lat)])
            item["action"] = "已钉入" if best_d > mp.radius * 0.5 else "已钉入（原本就顺路）"
            item["dist_after"] = 0.0
            report.append(item)
            cursor = best_i + 2          # 新点本身成为 pts[best_i+1]
        return pts, report

    scored = []
    for mp in must_points:
        best = min(_seg_dist_m(mp.lat, mp.lng, pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        scored.append((best, mp))
    scored.sort(key=lambda x: -x[0])

    for dist_before, mp in scored:
        item = {"name": mp.name or "未命名点", "dist_before": round(dist_before, 1),
                "radius": mp.radius, "action": ""}
        if dist_before <= mp.radius * 0.5:       # 已经在线附近，不折腾
            item["action"] = "已顺路（未改动）"
            report.append(item)
            continue
        best_i, best_d = 0, None
        for i in range(len(pts) - 1):
            d = _seg_dist_m(mp.lat, mp.lng, pts[i], pts[i + 1])
            if best_d is None or d < best_d:
                best_d, best_i = d, i
        pts.insert(best_i + 1, [float(mp.lng), float(mp.lat)])
        item["action"] = "已钉入"
        item["dist_after"] = 0.0
        report.append(item)

    return pts, report


# ============================================================ 配速 / 时长
def _scaled_caps(policy: P.Policy, base_km: float, run_km: float) -> Tuple[float, float]:
    """把学校的「时长上限」按**实际跑量**放大（下限**不**放大）。

    为什么上限要放大：学校的 `endQualifiedTime` 是针对 `totalRange` 说的。
    实跑 3.67 km 而学校只要求 2.5 km 时，上限 25 min 是对 2.5 km 说的 ⇒
    跑到 3.67 km 还卡 25 min，等于逼人 6′49″/km，这不是学校的要求，是我们自己算错
    （`tracklib.validity_checks` 早就按里程放大了，`plan` 这层没放大 —— 两层口径
    不一致，2026-11-13 审计抓到的 A1）。

    为什么下限**不**放大：学校的 `startQualifiedTime` 是**绝对**要求（"至少跑 10 分钟"），
    跑得越远自然越久，不需要同比抬。`tracklib.validity_checks` 也**只放大上限**
    （`aq`），下限 `start_q` 保持原值 —— 这里必须跟它完全一致，否则又是新的口径分裂。
    返回 (min_seconds, max_seconds)；`max_seconds=None` 表示不限。
    """
    if base_km is None or base_km <= 0 or run_km is None or run_km <= 0:
        return (policy.min_seconds or 0.0), policy.max_seconds
    ratio = float(run_km) / float(base_km)
    if abs(ratio - 1.0) < 1e-9:
        return (policy.min_seconds or 0.0), policy.max_seconds
    mx = policy.max_seconds * ratio if policy.max_seconds else None
    return (policy.min_seconds or 0.0), mx


def _pick_pace(policy: P.Policy, target_km: float,
               rng: Optional[random.Random] = None,
               *,
               base_km: Optional[float] = None) -> Tuple[float, List[str], List[Check]]:
    """按服务器要求选一个**既不会超速、也不会超时**的计划配速（秒/公里）。

    三条约束的来源不同：
      · 限速 → 配速不能**快于** `1000/limitSpeed`（配速是"秒/公里"，越大越慢）
      · 最短时长 → 跑完不能太快，否则时长不够
      · 最长时长 → 跑完不能太慢

    在**同时满足三者**的可行区间 `[lo, hi]` 里**随机取一个**（每次跑步配速不同，像真人）；
    区间为空才报冲突，并按「先保不合格会判作弊的限速」处理。

    `target_km` = 这次**实际**跑多少；`base_km` = 学校 `totalRange` 对应的里程
    （不传就当作等于 `target_km`，即老行为）。两者不同时，时长门槛按里程同比放大 ——
    否则"界面填 3.67 km"会被 2.5 km 的 25 min 上限卡成一个假的"要求冲突"。
    """
    notes: List[str] = []
    checks: List[Check] = []
    rng = rng or random.Random()

    _base = base_km if (base_km and base_km > 0) else target_km
    min_s, max_s = _scaled_caps(policy, _base, target_km)
    _scaled = (policy.min_seconds or policy.max_seconds) and abs(_base - target_km) > 1e-9

    floor = policy.pace_floor_s_per_km
    lo, lo_src = 0.0, ""
    hi, hi_src = float("inf"), ""
    if floor:
        need = floor * (1.0 + PACE_MARGIN)
        if need > lo:
            lo, lo_src = need, "限速 %.2f m/s ⇒ 不能快于 %s" % (policy.speed_limit_mps,
                                                              _fmt_pace(floor))
    if min_s and target_km > 0:
        need = min_s / target_km * (1.0 + TIME_MARGIN)
        if need > lo:
            lo, lo_src = need, "最短时长 %.0f 分钟" % (min_s / 60.0)
    if max_s and target_km > 0:
        cap = max_s / target_km * (1.0 - TIME_MARGIN)
        if cap < hi:
            hi, hi_src = cap, "最长时长 %.0f 分钟" % (max_s / 60.0)

    if lo > hi:
        # 学校要求自相矛盾（又要慢、又要快）。限速那条是"跑快了直接判作弊"，
        # 时长只是"这次不算数"，所以优先满足限速。
        pace = lo
        reasons = "；".join(filter(None, [lo_src, hi_src]))
        notes.append("学校要求互相冲突：%s —— 已优先满足%s，这条多半不会判合格"
                     % (reasons, lo_src or "下限"))
        checks.append(Check("时长", False,
                            "限速与时长上限无法同时满足（%s 需 ≥%s 且 ≤%s）"
                            % (("%.2f km" % target_km), _fmt_pace(lo),
                               _fmt_pace(hi) if hi != float("inf") else "不限")))
        return pace, notes, checks

    raw = rng.uniform(PACE_BASE_RANGE[0], PACE_BASE_RANGE[1])
    pace = min(max(raw, lo), hi)
    if floor:
        checks.append(Check("限速", True,
                            "限速 %.2f m/s ⇒ 不能快于 %s；计划 %s"
                            % (policy.speed_limit_mps, _fmt_pace(floor), _fmt_pace(pace))))
    if abs(pace - raw) > 1e-6:
        if pace == lo and lo_src:
            notes.append("按%s把计划配速收到 %s" % (lo_src, _fmt_pace(pace)))
        elif pace == hi and hi_src:
            notes.append("按%s把计划配速放到 %s" % (hi_src, _fmt_pace(pace)))

    est = target_km * pace / 60.0                        # 分钟
    ok_min = None if not min_s else est * 60.0 >= min_s - 1
    ok_max = None if not max_s else est * 60.0 <= max_s + 1
    if min_s or max_s:
        parts = ["预计 %.1f 分钟（%s）" % (est, _fmt_pace(pace))]
        if min_s:
            parts.append("要求 ≥%.0f" % (min_s / 60.0))
        if max_s:
            parts.append("≤%.0f" % (max_s / 60.0))
        if _scaled:
            # 说清楚这个门槛是**按里程放大后**的，否则界面显示"要求 ≤37 分钟"
            # 而学校设置里写的是 25 分钟，用户会以为我们改了他的设置。
            parts.append("（学校对 %.2f km 的设置已按 %.2f km 同比放大）"
                         % (_base, target_km))
        checks.append(Check("时长", (ok_min is not False and ok_max is not False),
                            " / ".join(parts)))
    return pace, notes, checks


def _fmt_pace(sec_per_km: Optional[float]) -> str:
    if not sec_per_km:
        return "—"
    m, s = divmod(int(round(sec_per_km)), 60)
    return "%d′%02d″/km" % (m, s)


def _setting_for_gen(policy: P.Policy, target_km: float) -> Dict[str, Any]:
    """喂给 `T.generate()` 的 setting（**故意不带 geofence**）。

    为什么不带：`geofence` 是 GCJ-02，而生成器内部样本是 WGS-84，原样传进去会让
    `check_geofence` 把每一个点都判成越界（差 500 米）。围栏自检我们自己在 `verify()`
    里用 `fence_wgs` 做，口径一致。

    其余字段都要按生成器认的单位给：`totalRange` 是 **km**（生成器内部再 ×1000）。

    ⚠️ `target_km` 必须是**学校下发的 `totalRange`**，不能是"这次实际跑多少"。
    生成器拿这份 setting 算 `isValid`（`tracklib.validity_checks`），而上传报文里
    服务端也是拿**它自己下发的那份额度**判。两边口径必须一致：
      · 传学校口径 ⇒ 生成器按 `endQ × 实跑/学校里程` 自动放大上限，`isValid` 与服务器一致
      · 传实跑里程 ⇒ `distance_m > total` 不成立、不放大，`isValid` 被算成 0，
        而上传时 `record_form` 又用原始 bean 重算成 1 —— 界面说"不合格"、报文说"合格"
        （2026-11-13 审计 A2 就是这么来的）。
    `isStepRecursion` 也一起带上：服务端 `step` 门槛是递归的，本地复核要同口径。
    """
    s: Dict[str, Any] = {"totalRange": target_km}
    if policy.speed_limit_mps:
        s["limitSpeed"] = str(policy.speed_limit_mps)
    if policy.stride_limit_m:
        s["endStride"] = str(policy.stride_limit_m)
    if policy.cadence_limit_spm:
        s["endLimitStepFrequency"] = str(int(round(policy.cadence_limit_spm)))
    if policy.step:
        s["step"] = policy.step
        # 服务端的步数门槛是**递归**的（超里程按比例抬）。原来这里只给了 step、
        # 没给标志位，本地复核就按"不递归"算，比服务器宽松 ⇒ 会放过不合格的记录。
        if policy.step_recursion is not None:
            s["isStepRecursion"] = 1 if policy.step_recursion else 0
    if policy.min_seconds:
        s["startQualifiedTime"] = policy.min_seconds / 60.0
    if policy.max_seconds:
        s["endQualifiedTime"] = policy.max_seconds / 60.0
    if policy.sequence is not None:
        s["isSequencePoint"] = "1" if policy.sequence else "0"
    return s


# ============================================================ 主入口：build
def _cadence_floor_stride(policy: P.Policy, speed: float) -> float:
    """步频上限换算出的**步幅下限**（米）。步频 = 速度 / 步幅 ⇒ 步幅 ≥ 速度×60/步频上限。

    这里**必须留 `CADENCE_MARGIN`**：`_pick_stride` 用的是理论均速，生成器落地的是
    「实际里程 / 步幅 / 实际运动时长」聚合出来的步频，两者有 ±0.75% 的固有偏差。
    贴线算（余量 0）就会出现"计划 179.5、实际 180.4"这种超限（第 906 轮实测）。
    """
    lim = float(policy.cadence_limit_spm or 0)
    if lim <= 0 or speed <= 0:
        return 0.0
    return speed * 60.0 / (lim * (1.0 - CADENCE_MARGIN))


def _pick_stride(policy: P.Policy, target_km: float, pace: float,
                 *, base_km: Optional[float] = None
                 ) -> Tuple[Optional[float], List[Check], float, float]:
    """选一个**同时满足步数门槛 / 步幅上限 / 步频上限**的步幅（米）。

    三个约束其实在描述同一件事（步数 = 里程 / 步幅）：
      · 步数 ≥ `step`            ⇒ 步幅 ≤ 里程 / step
      · 步幅 ≤ `endStride`       ⇒ 步幅 ≤ 上限
      · 步频 ≤ `endLimitStepFrequency` ⇒ 步幅 ≥ 速度 × 60 / 步频上限
    默认用「速度→步幅」模型值，再夹到 `[lo, hi]` 里。夹不下（lo > hi）说明学校设置
    自相矛盾（例如 2 km 要 2400 步、又不许步频超过 180），这时报 must 失败并退到 lo。

    `target_km` = 实跑里程，`base_km` = 学校 `totalRange`。步数门槛必须按**学校口径**
    算（`base_km / step`），不能按实跑里程 —— 否则"界面填 3.67 km、学校要 2.5 km 内
    2000 步"会解出 1.835 m 的步幅，而服务端 `isStepRecursion=1` 时按 `2000×3.67/2.5
    = 2936` 步判，我们实际只产出 ~2000 步 ⇒ 上传即不合格（审计 A3）。
    """
    checks: List[Check] = []
    if target_km <= 0 or pace <= 0:
        return None, checks, 0.0, 0.0
    _base = base_km if (base_km and base_km > 0) else target_km
    speed = 1000.0 / pace                     # m/s（计划均速）
    base = T.stride_for_speed(speed, "male")
    hi = float(base)
    hi_src = "模型值 %.3f m" % base
    if policy.stride_limit_m:
        # 留 1% 余量就够（步幅是「聚合值 = 里程/步数」，服务端也是这么算的）
        if policy.stride_limit_m * 0.99 < hi:
            hi = policy.stride_limit_m * 0.99
            hi_src = "步幅上限 %.2f m" % policy.stride_limit_m
    if policy.step:
        # ⚠️ 这里**不能**多留余量：步幅压小 ⇒ 步频必然升高，压过头就会撞上步频上限。
        # 正好取 里程/步数门槛（生成后里程只会 ≥ 目标，步数只会更多）。
        #
        # ⚠️ 但**里程要用学校口径的 `_base`，不是实跑里程**：学校说"2.5 km 内至少
        #    2000 步"时，跑 3.67 km 也得按同一步幅跑（步数自然变成 2936 步），
        #    而不是把步幅放大到 1.835 m（那样只有 2000 步，服务端按递归口径判不合格）。
        cap = _base * 1000.0 / float(policy.step)
        if policy.step_recursion:
            # 递归门槛（`isStepRecursion=1`）服务端是这么算的：
            #     need = ceil(step × 实跑里程 / 学校里程)
            # 生成器的实跑里程**总比目标多一点**（截断余量 + 必打点绕行 + 收尾段），
            # 于是 `ceil` 就把门槛抬上去了：2.4 km / 2095 步 ⇒ 实跑 2404.8 m 时
            # 门槛变成 ceil(2095×2404.8/2400)=2100，而我们按 2095 步设计步幅，
            # 产出 2099 步 ⇒ **差 1 步**被判不合格（1000 轮回归第 0 轮就抓到了）。
            # 留一点余量让步幅略小：按"实跑可能多 3%"折算，宁可多走几步。
            cap = cap / 1.03
        if cap < hi:
            hi = cap
            hi_src = "步数门槛 %d 步%s（步幅 ≤ %.3f m）" % (
                policy.step, "（递归）" if policy.step_recursion else "", cap)
    lo, lo_src = 0.50, ""
    if policy.cadence_limit_spm:
        # 步频 = 速度 / 步幅。速度必须按**这次实际要跑的配速**算（`speed` 已经是），
        # 但步幅若被"步数门槛"压到很小，步频就会顶穿上限 —— 这时正确的动作是
        # **放慢配速**（见 build 里的联合求解），而不是把步幅放大。
        #
        # ⚠️ 这里用**实跑里程**反推下限：步频是"全程平均"，与总里程无关，只看
        #    速度/步幅。但生成器的步幅是按 `_base/step` 定的、实际步数 = 实跑/步幅，
        #    实跑越长步数越多、步频越高。所以下限要按"实跑/步幅"能撑出的步频来卡。
        #
        # ⚠️ 余量：理论步频与实际步频有 ±0.75% 的固有偏差（见 `_cadence_floor_stride`），
        #    零余量就会贴线超限（第 906 轮：理论 179.5、实际 180.4）。
        need = _cadence_floor_stride(policy, speed)
        if need > lo:
            lo, lo_src = need, "步频上限 %.0f 步/分（步幅 ≥ %.3f m）" % (
                policy.cadence_limit_spm, need)
    # 矛盾判定要带**相对容差**：`build` 的联合求解是把配速反解到「lo 恰好等于 hi」的
    # 那个点（数学上相切），浮点来回乘除必然差个 1e-16 —— 严格 `hi < lo` 会把这个
    # 本来就成立的解判成"无解"，害得可行设置被开跑前自检拦下（1000 轮第 #247 轮）。
    if hi < lo * (1.0 - 1e-9):
        checks.append(Check(
            "步幅步频", False,
            "按当前配速解不出步幅：%s 要求 ≤ %.3f m，%s 又要求 ≥ %.3f m"
            % (hi_src, hi, lo_src or "下限", lo)))
        return lo, checks, hi, lo
    if hi < lo:
        lo = hi                      # 相切：取同一个值，两边都刚好满足
    stride = min(max(base, lo), hi)
    if policy.step or policy.stride_limit_m or policy.cadence_limit_spm:
        est_steps = int(round(target_km * 1000.0 / stride))
        checks.append(Check(
            "步幅步频", True,
            "步幅 %.3f m（%s）⇒ 约 %d 步、%.0f 步/分"
            % (stride, hi_src if stride == hi else (lo_src or "模型值"),
               est_steps, speed * 60.0 / max(stride, 1e-6))))
    return stride, checks, hi, lo


def _first_hit_order(path: Sequence[Sequence[float]],
                     must_points: Sequence[P.MustPoint],
                     *, sample_m: float = SAMPLE_SPACING_M,
                     shrink_m: float = HIT_SHRINK_M) -> List[int]:
    """沿折线**走一圈**，返回每个必打点"首次进入半径"的序号（按采样点先后）。

    用它来判"顺序到底能不能满足"：闭环上如果某个点被路径的另一段提前蹭到
    （半径 50 m 的点、路径在 40 m 外绕过去），第一圈就会先命中它，
    之后无论怎么排都错 —— 这种必须**开跑前**就说清楚，而不是等跑完被判不合格。

    ⚠️ **必须按生成器的真实落点粒度算，不能按精细几何算**（1000 轮第 #369 轮）。
    真机/生成器是 1 s 落一个点（≈3.3 m），而"是否进圈"只在**落点**上判定。

    ⚠️ 还要**把半径收一点**（`HIT_SHRINK_M`）：如果只按原半径算，点刚好擦着圈边
    （49.2 m vs 半径 50 m）会被算成"命中"，而实际 GPS 噪声 ±3 m 就能让它漏掉。
    收缩之后判"稳稳进圈"，才是真的能按顺序打卡。
    """
    dense = _densify(path, max(0.5, float(sample_m)))
    order: List[tuple] = []
    for idx, mp in enumerate(must_points):
        r = max(1.0, float(mp.radius) - float(shrink_m))
        hit = None
        for i, (lng, lat) in enumerate(dense):
            if T.haversine(mp.lat, mp.lng, lat, lng) <= r:
                hit = i
                break
        # ⚠️ **起点已在圈内**必须按原半径认（不能因收缩就排除）：
        #    这时"第一个落点就命中它"是硬事实，跟噪声无关。收缩只能用来判
        #    "走到圈边时算不算进去"，不能用来否认"起点本来就在里面"
        #    （1000 轮第 #404 轮：起点离点2 只有 42.9 m < 50 m，收缩到 42 m
        #     就把这个命中抹掉了，于是纸上顺序从 [1,0] 被"修正"成 [0,1]）。
        if hit is None and float(mp.radius) > 0 and dense:
            lng0, lat0 = dense[0]
            if T.haversine(mp.lat, mp.lng, lat0, lng0) <= float(mp.radius):
                hit = 0
        order.append((hit if hit is not None else INF_IDX, idx))
    order.sort()
    return [idx for _, idx in order]


def _seq_margin_report(path: Sequence[Sequence[float]],
                       must_points: Sequence[P.MustPoint]) -> List[str]:
    """算出「两圈重叠」的危险：走到前一个点时，是不是已经蹭进后一个点的圈。

    这是"能不能按顺序打卡"的**真正判据**。只看"进圈先后"不够 ——
    点1 与点3 相隔 50.9 m、点3 半径 50 m 时，纸上算出的顺序是对的 [0,1,2]，
    但一路过点1 就离点3 只有 0.9 m，GPS 噪声 ±3 m 随手把它抖进圈里，
    跑完按**真实落点**重排就成了 [0,2,1]（1000 轮第 #369 轮实测）。

    判据：路径经过点 i 的最近处时，到点 j 的距离还剩多少。若
    `d_path_to_j <= radius_j + HIT_SHRINK_M`，说明路过 i 的同时几乎肯定也进了 j 的圈，
    打点顺序就不再可控 —— 必须在开跑前拦下，让用户把线画开。

    返回：每条越界说明（空 = 所有点都彼此分得足够开）。
    """
    dense = _densify(path, max(0.5, SAMPLE_SPACING_M))
    names = [m.name or ("点%d" % (i + 1)) for i, m in enumerate(must_points)]
    out: List[str] = []
    # 逐点算出「路径到本点最近的那一处」，再就地量「到其它点多远」
    near_i: List[Tuple[float, int]] = []       # (最近距离, dense 下标)
    for mp in must_points:
        best_d, best_j = float("inf"), -1
        for j, (lng, lat) in enumerate(dense):
            d = T.haversine(mp.lat, mp.lng, lat, lng)
            if d < best_d:
                best_d, best_j = d, j
        near_i.append((best_d, best_j))
    for idx, mp in enumerate(must_points):
        near, j = near_i[idx]
        if j < 0 or near > float(mp.radius):
            continue                          # 这条线压根没进本点的圈，另由别的检查管
        lng, lat = dense[j]                   # 路径离本点最近的那个落点
        for jdx, other in enumerate(must_points):
            if jdx == idx:
                continue
            # ⚠️ **必须用"那个落点到 other 的真实距离"**，不能用三角下界
            #    `d_ij - near`：两者只差 20 m 量级时，下界会把「已经贴到 other 圈边」
            #    算成「还很远」（1000 轮第 #934 轮：点2/点3 相距 76.6 m、半径 30+30 m，
            #    路径先蹭到点3 边缘只剩 0.0 m，下界却算出 16.6 m 的安全感）。
            gap_to_other = T.haversine(other.lat, other.lng, lat, lng)
            if gap_to_other > float(other.radius) + HIT_SHRINK_M:
                continue                          # 分得够开
            out.append(
                "路过「%s」时离「%s」只剩 %.0f m（半径 %.0f m，安全余量需 ≥%.0f m）"
                "—— 两个圈叠在一起，走到前一个就等于进了后一个"
                % (names[idx], names[jdx], gap_to_other,
                   other.radius, HIT_SHRINK_M))
    return out


def _hit_ranks(path: Sequence[Sequence[float]],
               must_points: Sequence[P.MustPoint],
               *, sample_m: float = SAMPLE_SPACING_M) -> List[Tuple[int, int]]:
    """每个必打点的 `(首次进圈序号, 它自己的下标)`，按序号排序。

    与 `_first_hit_order` 的区别：这里**不收缩半径**（与服务端判定同口径），
    但用真实落点间距采样。用来量「顺序余量」。
    """
    dense = _densify(path, max(0.5, float(sample_m)))
    rows: List[Tuple[int, int]] = []
    for idx, mp in enumerate(must_points):
        r = float(mp.radius)
        hit = None
        for i, (lng, lat) in enumerate(dense):
            if T.haversine(mp.lat, mp.lng, lat, lng) <= r:
                hit = i
                break
        rows.append((hit if hit is not None else INF_IDX, idx))
    rows.sort()
    return rows


def _seq_check(path: Sequence[Sequence[float]], must_points: Sequence[P.MustPoint]) -> Check:
    """开跑前判「按顺序打卡」这件事在这条线上做不做得到。

    ⚠️ 口径必须与真机/生成器**一致**（落点间距 3.3 m + 半径收缩 8 m），
    否则就会出现 1000 轮第 #369 轮那种最坏情况：预检说「能按顺序过」，
    跑完复核却是「实际经过顺序 [0,2,1]」—— 用户按绿灯开跑、跑到一半被判不合格。
    """
    got = _first_hit_order(path, must_points)
    want = list(range(len(must_points)))
    names = [m.name or ("点%d" % (i + 1)) for i, m in enumerate(must_points)]
    # ⚠️ 下面所有 `False` 分支都是 `level="soft"`（B 方案）：
    #    顺序只是"跑出来可能打到后面那个点"，**不代表这条记录不合格** ——
    #    学校不下发 isSequencePoint=1 时（用户学校就是这种）服务端压根不看顺序。
    #    降级后界面照旧标出来，但不再拦开跑。见文件头 SOFT_CHECKS 的说明。
    # ① 结构性危险：两个圈叠在一起 ⇒ 纸上顺序对、实际也不可控
    overlap = _seq_margin_report(path, must_points)
    if overlap:
        return Check("打卡顺序", False,
                     "；".join(overlap[:2]) + " —— 把线画得离这些点远一点，或换个方向",
                     level=_soft("打卡顺序"))
    # ② **两套口径都要对**。`_first_hit_order` 收缩半径（判"稳稳进圈"），
    #    `_hit_ranks` 用原始半径（与服务端判定同口径）。两者结论不一致 = 危险：
    #    收缩后才成立的那个顺序，是靠"擦着圈边蹭进去"撑起来的，真实轨迹一偏就翻。
    #    1000 轮 #162/#210/#276 就是这种：起点离点2 只有 28.8 m（半径 30 m），
    #    真实第一个落点直接命中它，而收缩口径要到第 6 个点才算进圈。
    ranks = _hit_ranks(path, must_points)
    ranks_order = [idx for _, idx in ranks]
    if ranks_order != want:
        bad0 = next((i for i, (a, b) in enumerate(zip(ranks_order, want)) if a != b), 0)
        return Check(
            "打卡顺序", False,
            "按真实落点算，先经过「%s」，而下发的第 %d 个是「%s」—— 起点或线离这些点太近，"
            "第一圈会先蹭到后面的点。把起点挪开、或把线画得离这些点远一点"
            % (names[ranks_order[bad0]], bad0 + 1, names[want[bad0]]),
            level=_soft("打卡顺序"))
    # ③ 顺序余量：按**真实落点间距**看相邻两次进圈隔了多少米。
    #    隔得太近（比如只差 7 个落点 ≈23 m）时，GPS 噪声 / 起步跳过就能让它们翻序
    #    —— 这种"纸上对、实际险"的情况也必须提前拦（1000 轮第 #934 轮实测）。
    if len(ranks) >= 2 and all(r[0] != INF_IDX for r in ranks):
        _dense_step = max(0.5, SAMPLE_SPACING_M)
        for (i0, a), (i1, b) in zip(ranks, ranks[1:]):
            gap_m = (i1 - i0) * _dense_step
            if gap_m < HIT_ORDER_GAP_M:
                return Check(
                    "打卡顺序", False,
                    "「%s」与「%s」会几乎同时进圈（相隔仅 %.0f m 的路径，安全余量需 ≥%.0f m）"
                    "—— 两点的判定圈贴在一起，真实轨迹很容易把它们判反。"
                    "把线画得让它们错开，或换条线"
                    % (names[a], names[b], gap_m, HIT_ORDER_GAP_M),
                    level=_soft("打卡顺序"))
    if got == want:
        return Check("打卡顺序", True,
                     "沿这条线走一圈，会按 %d 个点的下发顺序依次经过" % len(must_points))
    # 找出第一个错位的点，说人话
    bad = next((i for i, (a, b) in enumerate(zip(got, want)) if a != b), 0)
    # 补一句"到底是哪两个点挨太近"—— 只说"顺序错了"用户没法改线
    _why = ""
    try:
        a, b = must_points[want[bad]], must_points[got[bad]]
        _d = T.haversine(a.lat, a.lng, b.lat, b.lng)
        if _d <= a.radius + b.radius:
            _why = ("（「%s」与「%s」只隔 %.0f m，而判定半径 %.0f+%.0f m —— "
                    "两个圈叠在一起，走到前一个就等于进了后一个）"
                    % (names[want[bad]], names[got[bad]], _d, a.radius, b.radius))
    except Exception:                                # noqa: BLE001
        pass
    return Check(
        "打卡顺序", False,
        "这条线上先经过「%s」，而下发的第 %d 个是「%s」%s —— 半径太大或线绕得太近，"
        "第一圈会先蹭到后面的点。把线画得离这些点远一点，或者换个方向再试"
        % (names[got[bad]], bad + 1, names[want[bad]], _why),
        level=_soft("打卡顺序"))


def _fence_centroid(policy: P.Policy) -> Optional[Tuple[float, float]]:
    """围栏质心（WGS，(lng,lat)）。没有围栏返回 None。"""
    xs: List[float] = []
    ys: List[float] = []
    for poly in policy.fence_wgs:
        for q in poly:
            xs.append(float(q["lng"]))
            ys.append(float(q["lat"]))
    if not xs:
        return None
    return (sum(xs) / len(xs), sum(ys) / len(ys))


def auto_ring(policy: P.Policy) -> Optional[List[List[float]]]:
    """**没画线时的兜底**：用当次必经点绕围栏质心排一圈，连成闭合环（WGS）。

    这不是主路径（主路径是你画的线），只是为了"点了一键开跑但还没画"时不至于报错。
    算法：按极角排序 → 相邻点之间向质心内凹（取 70% 处）→ 首尾闭合。
    内凹是为了贴着围栏内部走，避免直线边穿出不规则多边形。

    必经点少于 2 个返回 None（1 个点连不成环，交给调用方回落旧逻辑）。
    """
    must = policy.must_points
    if len(must) < 2:
        return None
    centroid = _fence_centroid(policy) or (
        sum(m.lng for m in must) / len(must), sum(m.lat for m in must) / len(must))
    clng, clat = centroid
    # 要求按顺序打卡时**不能按极角重排** —— 极角排出来的环，实际经过顺序常常与下发相反
    # （下发顺序是学校定的，可能是顺时针，也可能从一个"拐角点"起步）。
    ordered = list(must) if policy.sequence is True else \
        sorted(must, key=lambda m: math.atan2(m.lat - clat, m.lng - clng))
    pts = [[m.lng, m.lat] for m in ordered]
    ring: List[List[float]] = []
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        mid = [(a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0]
        ring.append(a)
        ring.append([clng + (mid[0] - clng) * 0.7, clat + (mid[1] - clat) * 0.7])
    ring.append(list(pts[0]))
    return ring


def build(policy: P.Policy, points: Sequence[Any], *,
          run_type: Optional[int] = None, identify: str = "",
          start_ms: Optional[int] = None, seed: Optional[int] = None,
          fill_to_target: bool = True, device: Optional[Dict[str, Any]] = None,
          app_version: Optional[str] = None,
          start_delay_s: Optional[float] = None,
          target_km_override: Optional[float] = None) -> Plan:
    """Policy + 你画的线 → 开跑计划（含开跑前自检）。

    `points` 接受 `[{lat,lng}]` 或 `[[lng,lat]]`；内部一律 WGS-84。
    不抛异常：任何问题都变成一条 `Check(ok=False)`，让界面自己决定要不要拦。

    `target_km_override` = **界面上填的目标里程**（多跑一点用）。
    为什么不直接用 `policy.target_km`：那是学校要求的**最低**里程，而用户经常想跑
    3.67 km 而不是 2.5 km。2026-11-13 之前这个参数根本不存在，`flow` 也没把
    前端 `params.target_km` 传进来 ⇒ 界面算 3.67、实际跑 2.5，**所见非所跑**。
    ⚠️ 覆盖只改"跑多远"，**不改**学校要求（时长/步数/限速的下限仍按学校口径放大）。
    """
    plan = Plan()
    rt = policy.run_type if run_type is None else run_type
    rng = random.Random(seed) if seed is not None else random.Random()

    path = T.normalize_path(points or [])
    if len(path) < 2:
        plan.checks.append(Check("折线", False, "至少需要两个点 —— 先把轨迹画出来"))
        return plan
    if len(path) < 3:
        plan.notes.append("折线只有两个点，会有明显的来回折返，建议多画几个拐点")

    # ---------- 目标里程 ----------
    # 学校要求的下限（policy.target_km）与"这次实际要跑多少"（run_km）分开：
    #   · policy.target_km → 所有**门槛**（步数、时长、人脸位置）都按它算，这是学校口径
    #   · run_km            → 生成器跑多远。默认等于 policy.target_km；界面填了更多就跑更多
    # 多跑是安全的（学校只要求"不少于"），少跑才不合格 —— 所以这里只允许向上覆盖。
    target_km = policy.target_km
    if not target_km:
        target_km = DEFAULT_TARGET_KM
        plan.notes.append("服务器没下发目标里程，按默认 %.2f km 跑" % target_km)
    plan.checks.append(Check("目标里程", True, "%.2f km（服务器下发）" % target_km
                             if policy.target_km else "%.2f km（默认值）" % target_km))
    run_km = target_km
    if target_km_override is not None:
        try:
            _ov = float(target_km_override)
        except (TypeError, ValueError):
            _ov = 0.0
        if _ov > 0 and abs(_ov - target_km) > 1e-6:
            if _ov < target_km - 1e-6:
                # 想跑得比学校要求还少 ⇒ 这条一定不合格，明确拦住（不是"帮你改大"）
                plan.checks.append(Check(
                    "目标里程", False,
                    "界面填的 %.2f km 少于学校要求的 %.2f km —— 跑完也不算合格，"
                    "请填 ≥%.2f km" % (_ov, target_km, target_km)))
            else:
                run_km = _ov
                plan.checks.append(Check(
                    "目标里程", True,
                    "界面填 %.2f km（学校要求 ≥%.2f km，多跑 %.2f km）"
                    % (_ov, target_km, _ov - target_km)))
                plan.notes.append(
                    "按界面填的 %.2f km 跑（学校只要求 ≥%.2f km）；"
                    "步数/时长/人脸位置仍按学校的 %.2f km 口径算"
                    % (_ov, target_km, target_km))

    # ---------- 钉打卡点 ----------
    len_before = T.path_length_m(path)
    _seq = policy.sequence is True
    if _seq and policy.must_points:
        path, _seq_note = align_path_to_sequence(path, policy.must_points)
        if _seq_note:
            plan.notes.append(_seq_note)
            plan.checks.append(Check("打卡顺序", True, _seq_note))
        plan.notes.append("学校要求按顺序打卡：%d 个点按**下发顺序**依次穿过"
                          % len(policy.must_points))
    plan.path, plan.must_report = inject_must_points(
        path, policy.must_points, sequence=_seq)
    len_after = T.path_length_m(plan.path)

    # 顺序能不能真满足，**开跑前**就判（不许跑完才发现"先打到后面那个点"）
    if _seq and plan.must_report:
        # 「钉进去要来回折返」：必打点离线超过 2 倍半径时，插入它等于让路径伸出去再折回来；
        # 折返途中会先蹭到**后面**那些点（3 个点挤在一小段上时，实测顺序必错）。
        _kinks = [r for r in plan.must_report
                  if r.get("dist_before", 0) > 2.0 * max(1.0, r.get("radius") or 30.0)
                  and not r.get("failed")]
        if _kinks:
            plan.checks.append(Check(
                "打卡顺序", False,
                "%s 离线太远（超过 2 倍打卡半径），钉进去会让路线伸出去再折回来，"
                "折返途中会先蹭到后面的点 —— 建议把线画得更靠近这些点"
                % "、".join("%s %.0f m" % (r["name"], r["dist_before"]) for r in _kinks),
                level=_soft("打卡顺序")))
    if _seq and policy.must_points:
        _bad_seq = [r for r in plan.must_report if r.get("failed")]
        if _bad_seq:
            # ⚠️ 这一条**不能降级**（与上面「打卡顺序」不同）：`failed=True` 不是"顺序不理想"，
            #    而是「这个点**压根没被钉进线里**」—— 生成器不会经过它 ⇒ 跑完必然漏点、
            #    必然判不合格（`verify` 的「必经打卡点」是 must，也会拦）。
            #    降级它等于"开跑前放行、跑完才发现漏点"，正是 B 方案最该避免的情况。
            #    所以单独一条名字（不再叫"打卡顺序"），级别保持 must。
            plan.checks.append(Check(
                "必经点顺序冲突", False,
                "按学校下发的顺序，%s 排在线尾之后 —— 想按顺序穿完得再绕一整圈，"
                "现在这样跑会漏掉它。建议把线画成与下发顺序同向（或直接点「自动成环」）"
                % "、".join(r["name"] for r in _bad_seq)))
        elif len(policy.must_points) >= 2:
            plan.checks.append(_seq_check(plan.path, policy.must_points))

    if policy.must_points and policy.fence_wgs:
        # 必打点自己贴着围栏边（离边界 < 安全边距）⇒ 无论怎么跑，经过它的那个采样点
        # 都会落在边界上，上传后必被判"围栏外"。这种要在开跑前说清楚。
        near_edge = []
        for mp in policy.must_points:
            ok, d = _fence_verdict(mp.lng, mp.lat, policy.fence_wgs, FENCE_MARGIN_M)
            if not ok:
                near_edge.append((mp.name or "未命名点", d))
        if near_edge:
            plan.checks.append(Check(
                "必打点贴边", False,
                "%s 离围栏边界太近（最近 %.1f m，要求 ≥%.1f m）—— 经过它的点上传后会被判"
                "「围栏外」。建议换一条线，或等下一次 getSetting 重新下发打卡点"
                % ("、".join("%s %.1f m" % (n, d) for n, d in near_edge),
                   min(d for _, d in near_edge), FENCE_MARGIN_M)))
    if policy.must_points:
        worst = max((r["dist_before"] for r in plan.must_report), default=0.0)
        plan.checks.append(Check(
            "必经打卡点", True,
            "%d 个；离线最远 %.0f m，已全部处理" % (len(policy.must_points), worst)))
        for r in plan.must_report:
            if r["action"] == "已顺路（未改动）" and r["dist_before"] > r["radius"]:
                # 理论上不会发生（够近才不改），留着当断言用
                plan.checks.append(Check("打卡点 %s" % r["name"], False,
                                         "离线 %.0f m 超过半径 %.0f m"
                                         % (r["dist_before"], r["radius"])))
        # 钉点是有代价的：点离线多远，线就要伸出去多远再拐回来（约 2 倍）。
        # 判据不能用"百分比"—— 短线上插三个点很容易就 30%+，但那只是几何必然，不是画错了。
        # 真正该提醒的是**绝对量**：有个点离线特别远（>100 m），或总绕行超过半公里。
        inserted = [r for r in plan.must_report if r["action"] == "已钉入"]
        far_m = max((r["dist_before"] for r in inserted), default=0.0)
        detour = len_after - len_before
        if far_m > 100.0 or detour > 500.0:
            far = sorted(inserted, key=lambda r: -r["dist_before"])[:3]
            plan.checks.append(Check(
                "钉点代价", False,
                "为了穿过打卡点，线被拉长 %.0f m。离线最远的是 %s —— "
                "建议把线画得更贴近红点，否则跑出来的形状和画的不一样"
                % (detour, "、".join("%s %.0f m" % (r["name"], r["dist_before"]) for r in far)),
                level=_soft("钉点代价")))
        elif far_m > 50.0:
            plan.notes.append("为穿过打卡点，线被拉长 %.0f m（点离线最远 %.0f m）"
                              % (detour, far_m))
    else:
        plan.checks.append(Check("必经打卡点", None, "学校未下发，无需穿点"))

    # ---------- 起跑里程 vs 必打点覆盖 ----------
    # 跑多远 = run_km（界面填的 / 学校要求的较大者）；必打点覆盖要按**这个**判，
    # 否则"界面填 3.67 km"时还按 2.5 km 检查折线够不够长，结论是错的。
    fill_km = run_km

    # ---------- 需要绕几圈 ----------
    if len_after > 0 and fill_km * 1000.0 / len_after > 3.0:
        plan.notes.append("折线只有 %.0f m，要到 %.2f km 得绕 %.1f 圈 —— 想让形状更像真跑，"
                          "可以把线画长一点" % (len_after, fill_km,
                                                fill_km * 1000.0 / len_after))

    # ---------- 「跑完 target 里程」能不能覆盖所有必打点 ----------
    # 这一步很容易被忽略，但它是"钉了点却还是没经过"的根因：
    # 若折线本身比目标里程**长**，生成器跑到 target 就停，落在后面的必打点压根走不到
    # （首轮回归：0.85 km 目标、环长 0.9 km，第 2 个点在 94% 处 ⇒ 距它最近也只有 60 m）。
    # 处理：把目标里程抬到"能走到最后一个必打点"的长度，并说清楚抬了多少。
    if policy.must_points and len_after >= fill_km * 1000.0:
        need_m = 0.0
        for mp in policy.must_points:
            best_i, best_d = 0, None
            for i, q in enumerate(plan.path):
                d = T.haversine(mp.lat, mp.lng, q[1], q[0])
                if best_d is None or d < best_d:
                    best_d, best_i = d, i
            need_m = max(need_m, T.path_length_m(plan.path[:best_i + 1]))
        if need_m > fill_km * 1000.0 - 1.0:
            old = fill_km
            fill_km = round(need_m * 1.02 / 1000.0, 3)
            plan.notes.append(
                "折线长 %.0f m，跑完 %.2f km 到不了最后一个必经点（它在 %.0f m 处）—— "
                "目标里程已抬到 %.2f km，保证先穿过所有点再收尾"
                % (len_after, old, need_m, fill_km))
            plan.checks.append(Check(
                "必打点覆盖", True,
                "目标 %.2f km → %.2f km（折线比目标长，不抬就会漏点）" % (old, fill_km)))
            # 只跟**学校要求的里程**比：多跑是为了穿点，形状偏离学校要求多少才是关键。
            _over = need_m / max(1.0, target_km * 1000.0) - 1.0
            if _over > 0.50:
                # 多跑 50% 以上：这条记录的形状已经和"学校要求的里程"差太远，
                # 服务器按里程/配速比对时容易看出不对。**B 方案下不再拦开跑**：
                # 用户口径是"能按画的线跑起来就行"，而多跑本身不会让记录判无效
                # （服务器只要求 ≥ 目标里程），所以只标黄提示他把线画短。
                plan.checks.append(Check(
                    "必打点覆盖", False,
                    "为了穿过所有必经点要多跑 %.0f m（+%.0f%%）—— 里程够但形状会偏离，"
                    "建议把线画短/画顺一点（不拦开跑）"
                    % (need_m - target_km * 1000.0, _over * 100),
                    level=_soft("必打点覆盖")))
            elif _over > 0.20:
                plan.checks.append(Check(
                    "必打点覆盖", True,
                    "为穿过必经点多跑 %.0f m（+%.0f%%），已在回执里说明"
                    % (need_m - target_km * 1000.0, _over * 100), level=_soft("必打点覆盖")))

    # ---------- 配速 / 时长 ----------
    # 时长门槛按「学校口径 target_km → 实跑 fill_km」同比放大（见 _scaled_caps）
    pace, notes, pace_checks = _pick_pace(policy, fill_km, rng=rng, base_km=target_km)
    plan.notes.extend(notes)
    plan.checks.extend(pace_checks)

    # ---------- 步幅 / 步频（与配速**联合**求解） ----------
    # 关键点：步频 = 速度 / 步幅。学校同时限「步数 ≥ N」和「步频 ≤ M」时，两者会互相挤压 ——
    # 步数多 ⇒ 步幅小 ⇒ 步频高。这种时候正确的动作是**放慢配速**（而不是报"无解"）：
    # 2.25 km 要 1933 步（步幅 1.164 m）、步频上限 180 ⇒ 速度必须 ≤ 3.49 m/s，即 4′46″/km。
    # 首轮回归里就有一轮是"其实能跑、被我们判成矛盾"。
    stride_m, stride_checks, _stride_hi, _ = _pick_stride(
        policy, fill_km, pace, base_km=target_km)
    if policy.cadence_limit_spm and _stride_hi > 0 \
            and any(c.ok is False for c in stride_checks):
        # 配速反解：让步幅上限 `_stride_hi` 刚好压住步频上限。
        # 系数与 `_cadence_floor_stride` 同一个（1/(1-2%)），两边口径必须一致，
        # 否则解出来的配速会差 2% —— 校验说"能跑"、生成器却又贴线超限。
        _need_pace = 60000.0 / (float(policy.cadence_limit_spm)
                                * (1.0 - CADENCE_MARGIN) * _stride_hi)
        _min_s2, _max_s2 = _scaled_caps(policy, target_km, fill_km)
        _cap_pace = ((_max_s2 / fill_km) * (1.0 - TIME_MARGIN)
                     if _max_s2 else float("inf"))
        if pace < _need_pace <= _cap_pace:
            pace = _need_pace
            plan.notes.append(
                "按步频上限 %.0f 步/分把配速放慢到 %s（步幅 %.3f m 才压得住步频）"
                % (policy.cadence_limit_spm, _fmt_pace(pace), _stride_hi))
            stride_m, stride_checks, _stride_hi, _ = _pick_stride(
                policy, fill_km, pace, base_km=target_km)
            # 配速变慢后，时长判定也要重算 —— **先从 plan.checks 里摘掉旧的**
            # （前面已经 extend 过了，不摘就会同时挂两条互相矛盾的"时长"）
            plan.checks[:] = [c for c in plan.checks if c.name != "时长"]
            _est = fill_km * pace / 60.0
            _ok_min = None if not _min_s2 else _est * 60.0 >= _min_s2 - 1
            _ok_max = None if not _max_s2 else _est * 60.0 <= _max_s2 + 1
            if _min_s2 or _max_s2:
                _parts = ["预计 %.1f 分钟（%s）" % (_est, _fmt_pace(pace))]
                if _min_s2:
                    _parts.append("要求 ≥%.0f" % (_min_s2 / 60.0))
                if _max_s2:
                    _parts.append("≤%.0f" % (_max_s2 / 60.0))
                if abs(target_km - fill_km) > 1e-9:
                    _parts.append("（学校对 %.2f km 的设置已按 %.2f km 同比放大）"
                                  % (target_km, fill_km))
                plan.checks.append(Check("时长", (_ok_min is not False and _ok_max is not False),
                                         " / ".join(_parts)))
            plan.notes.append("配速调整后预计 %.1f 分钟" % _est)
    plan.checks.extend(stride_checks)

    # ---------- 跑步规定时间 ----------
    # 「服务器给的开跑时刻」落在学校公布的时段内，才可能被判合格。
    # 时段认不出来就记「未下发」（灰着），不拦 —— 服务器若在禁跑时段给 startTime，
    # 那后面 addExerciseRecord 自己会回错误码，用不着我们猜。
    win = policy.run_window or {}
    if win and start_ms:
        try:
            lt = time.localtime(int(start_ms) / 1000.0)
            cur = lt.tm_hour * 60 + lt.tm_min
            s_min, e_min = int(win["start_min"]), int(win["end_min"])
            if s_min <= e_min:
                inside = s_min <= cur <= e_min
            else:                                   # 跨零点（如 22:00–02:00）
                inside = cur >= s_min or cur <= e_min
            plan.checks.append(Check(
                "跑步规定时间", inside,
                "开跑时刻 %02d:%02d，学校时段 %s–%s%s"
                % (lt.tm_hour, lt.tm_min, win["start"], win["end"],
                   "" if inside else "　← 不在时段内，服务器多半不接受")))
        except Exception:                            # noqa: BLE001
            plan.checks.append(Check("跑步规定时间", None, "时段解析失败，按「不校验」处理"))
    elif win:
        plan.checks.append(Check("跑步规定时间", None,
                                 "学校时段 %s–%s（开跑时刻由服务器下发）"
                                 % (win["start"], win["end"])))
    else:
        plan.checks.append(Check("跑步规定时间", None,
                                 "学校未下发时段 —— 以服务器下发的开跑时刻为准"))

    # ---------- 围栏（静态，加密采样；要求离边界 ≥ 安全边距） ----------
    if policy.fence_wgs:
        dense = _densify(plan.path, 10.0)
        bad_pts = []
        for lng, lat in dense:
            ok, d = _fence_verdict(lng, lat, policy.fence_wgs, FENCE_MARGIN_M)
            if not ok:
                bad_pts.append(round(d, 1))
        plan.checks.append(Check(
            "有效区域", not bad_pts,
            ("整条线都在围栏内（离边界最近 %.1f m，已留 %.1f m 余量）"
             % (min((_fence_verdict(lng, lat, policy.fence_wgs, 0.0)[1]
                      for lng, lat in dense), default=0.0), FENCE_MARGIN_M))
            if not bad_pts else
            "%d 个采样点贴边/越界（共 %d）：最严重的离边界 %.1f m，要求 ≥%.1f m"
            % (len(bad_pts), len(dense), min(bad_pts), FENCE_MARGIN_M)))
        start_in, _sd = _fence_verdict(plan.path[0][0], plan.path[0][1],
                                       policy.fence_wgs, FENCE_MARGIN_M * 0.4)
        end_in, _ed = _fence_verdict(plan.path[-1][0], plan.path[-1][1],
                                     policy.fence_wgs, FENCE_MARGIN_M * 0.4)
        plan.checks.append(Check("起终点", start_in and end_in,
                                 ("起点%s围栏（离边界 %.0f m）· 终点%s围栏（%.0f m）"
                                  % ("在" if start_in else "不在", _sd,
                                     "在" if end_in else "不在", _ed))))
    else:
        plan.checks.append(Check("有效区域", None, "学校未下发围栏"))

    # ---------- 人脸 ----------
    faces_on = bool(policy.face_start or policy.face_end or policy.face_mid_ratios)
    if policy.face_start is None and policy.face_end is None and not policy.face_mid_ratios:
        plan.notes.append("人脸要求没识别出来，按「免打卡」处理 —— 如果这所学校要扫脸，需要覆盖层")
    plan.checks.append(Check("人脸打卡", None,
                             "、".join(filter(None, [
                                 "开始" if policy.face_start else "",
                                 ("中途 ×%d" % len(policy.face_mid_ratios)) if policy.face_mid_ratios else "",
                                 "结束" if policy.face_end else ""])) or "免打卡"))

    # ---------- 参数 ----------
    # 起跑延迟：参考实现是 `startTime + random(14, 20) s` —— 服务器给的时刻是"可以开跑"，
    # 真人从看到倒计时到真正迈步要十几秒。差这十几秒有两个好处：
    #   ① 记录 startTime 不会与"刚请求完就上传"完全重合（那是脚本特征）；
    #   ② 结束人脸 / 收尾段都落在真实墙钟上，不会出现 endTime 早于上传时刻。
    _delay = None
    if start_delay_s is None:
        _delay = round(rng.uniform(START_DELAY_S[0], START_DELAY_S[1]), 1)
    else:
        _delay = max(0.0, float(start_delay_s))
    _actual_start = (int(start_ms) + int(round(_delay * 1000.0))) if start_ms else start_ms
    plan.params = {
        "path": plan.path,
        # 生成器跑多远 = fill_km（界面填的 / 学校要求抬到必打点后的较大值）。
        # 这是"所见即所跑"的关键：前端 `#tkm` 填 3.67，这里就必须是 3.67。
        "target_km": float(fill_km),
        "plan_pace_s_per_km": float(pace),
        "start_ms": _actual_start,
        "run_type": int(rt),
        "identify": identify or policy.identify or "identify-pending",
        # setting 里的 totalRange 是**学校口径**（target_km），不是 fill_km ——
        # 生成器拿它算 isValid，必须和服务端下发的那份额度一致（见 _setting_for_gen）。
        "setting": _setting_for_gen(policy, target_km),
        "start_face": bool(policy.face_start),
        "end_face": bool(policy.face_end),
        "middle_faces": list(policy.face_mid_ratios) or None,
        # 必经点原样交给生成器：它负责算 okPointList（到达时刻表）。
        "must_points": [p.as_dict() for p in policy.must_points] or None,
        # 步幅：与「步数门槛 / 步幅上限 / 步频上限」三个约束一起解出来的值（None = 用模型）
        "stride_m": stride_m,
        "crs": "gcj02",                 # 上传用 GCJ-02（内部 path 仍是 WGS）
        "loop_mode": "repeat" if fill_to_target else "once",
        "seed": seed,
    }
    plan.start_delay_s = _delay
    plan.server_start_ms = start_ms
    plan.actual_start_ms = _actual_start
    # 让上层（flow / 界面）能分辨"学校要求"与"这次跑多少"：
    #   target_km = 学校口径（门槛都按它算）· run_km = 这次实际要跑的里程
    plan.require_km = float(target_km)
    plan.run_km = float(fill_km)
    if _delay:
        plan.notes.append("起跑延迟 %.1f s（服务器时刻 %s → 实际起步 %s）"
                          % (_delay,
                             _fmt_hms(start_ms), _fmt_hms(_actual_start)))
    if device:
        plan.params["device"] = device
    if app_version:
        plan.params["app_version"] = app_version
    return plan


def _fmt_hms(ms) -> str:
    try:
        return time.strftime("%H:%M:%S", time.localtime(int(ms) / 1000.0))
    except Exception:                                # noqa: BLE001
        return "—"


# ============================================================ 生成后：verify
def verify(policy: P.Policy, gen: Dict[str, Any]) -> List[Check]:
    """拿**真实生成**的轨迹复核一遍。这是开跑前最后一道闸。

    复用 `tracklib.validity_checks` 的结论（里程/时长/步数/限速/步幅/步频），
    再补三样它不管的：围栏、打卡点覆盖、打卡顺序。
    """
    checks: List[Check] = []
    metrics = gen.get("metrics") or {}

    for c in ((gen.get("validity") or {}).get("checks") or []):
        checks.append(Check(str(c.get("name")), bool(c.get("ok")), str(c.get("detail") or "")))

    samples = gen.get("export_samples") or gen.get("samples") or []

    # ---------- 围栏 ----------
    if policy.fence_wgs and samples:
        bad_n, worst = 0, 0.0
        for s0 in samples:
            ok, d = _fence_verdict(float(s0["lng"]), float(s0["lat"]),
                                   policy.fence_wgs, FENCE_MARGIN_M)
            if not ok:
                bad_n += 1
                worst = min(worst, d)
        checks.append(Check(
            "有效区域", bad_n == 0,
            ("全部在围栏内（离边界最近 %.1f m）"
             % min((_fence_verdict(float(x["lng"]), float(x["lat"]),
                                   policy.fence_wgs, 0.0)[1] for x in samples), default=0.0))
            if bad_n == 0 else
            "%d/%d 个点贴边或越界（最严重 %.1f m，要求 ≥%.1f m）"
            % (bad_n, len(samples), worst, FENCE_MARGIN_M)))
    elif policy.fence_wgs:
        checks.append(Check("有效区域", False, "生成了空轨迹"))

    # ---------- 围栏（**上传口径**：GCJ 坐标 vs GCJ 围栏）----------
    # 服务器判的就是这一份。以前只按内部 WGS 自检 —— 两次坐标换算 + 噪声正好能把
    # 贴边的点甩出去（实测 2680 m 的轨迹里有 2/941 个），自检过了服务器却判越界。
    pts_up = gen.get("track_pointdata") or []
    if policy.fence_gcj and pts_up:
        out_n, first = 0, None
        for q in pts_up:
            try:
                lng, lat = float(q.get("o")), float(q.get("a"))
            except (TypeError, ValueError):
                continue
            if not any(P.point_in_poly(lng, lat,
                                       [(float(w["lng"]), float(w["lat"])) for w in poly])
                       for poly in policy.fence_gcj):
                out_n += 1
                if first is None:
                    first = "%s,%s" % (lat, lng)
        checks.append(Check(
            "有效区域（上传坐标）", out_n == 0,
            "上传的 %d 个 GCJ 点全部在围栏内" % len(pts_up) if out_n == 0
            else "%d/%d 个上传点越界（首个 %s）—— 服务器会按这个判" % (out_n, len(pts_up), first)))

    # ---------- 打卡点覆盖 ----------
    if policy.must_points:
        if not samples:
            checks.append(Check("必经打卡点", False, "生成了空轨迹，无法判定"))
        else:
            worst = None
            for mp in policy.must_points:
                d = min(T.haversine(mp.lat, mp.lng, float(s["lat"]), float(s["lng"]))
                        for s in samples)
                if worst is None or d > worst[1]:
                    worst = (mp, d)
            ok = worst[1] <= worst[0].radius
            checks.append(Check(
                "必经打卡点", ok,
                "全部经过（最远 %s 距离 %.1f m / 半径 %.0f m）"
                % (worst[0].name or "未命名点", worst[1], worst[0].radius)
                if ok else
                "%s 距离 %.1f m 超出半径 %.0f m —— 这条轨迹不会判合格"
                % (worst[0].name or "未命名点", worst[1], worst[0].radius)))
        # 时刻表（okPointList）必须与"真的经过"一一对应：少了就是声称打了没打的点。
        okl = gen.get("ok_point_list") or []
        if len(okl) != len(policy.must_points):
            checks.append(Check(
                "打卡时刻表", False,
                "下发 %d 个必经点，时刻表只有 %d 个 —— 上传会与轨迹对不上"
                % (len(policy.must_points), len(okl))))
        else:
            checks.append(Check("打卡时刻表", True,
                                "%d 个点，时间按实际经过时刻生成" % len(okl)))

    # ---------- 人脸点是否齐全、时间是否落在轨迹区间内 ----------
    if policy.face_start or policy.face_end or policy.face_mid_ratios:
        faces = gen.get("faces") or []
        types = [int(f.get("type") or 0) for f in faces]
        miss = []
        if policy.face_start and 1 not in types:
            miss.append("开始(1)")
        if policy.face_end and 3 not in types:
            miss.append("结束(3)")
        if policy.face_mid_ratios:
            want_mid = len(policy.face_mid_ratios)
            got_mid = types.count(2)
            # 两个中途点挨得太近时生成器会去重（<5 s），那种只要求 ≥1 个
            ratios = sorted(policy.face_mid_ratios)
            close = all(b - a < 0.05 for a, b in zip(ratios, ratios[1:])) if want_mid > 1 else False
            if got_mid < (1 if (want_mid == 1 or close) else min(want_mid, 2)):
                miss.append("中途(2) 需要%d个/实际%d个" % (want_mid, got_mid))
        if samples:
            lo, hi = int(samples[0]["t_ms"]), int(samples[-1]["t_ms"])
            for f in faces:
                t = int(f.get("timestamp") or 0)
                if not (lo - 1000 <= t <= hi + 1000):
                    miss.append("faceType=%s 时间 %.0f s 落在轨迹 [%.0f, %.0f] 外"
                                % (f.get("type"), t / 1000.0, lo / 1000.0, hi / 1000.0))
        checks.append(Check("人脸点", not miss,
                            "%d 个（开始/中途/结束齐全，时间都在轨迹区间内）" % len(faces)
                            if not miss else "；".join(dict.fromkeys(miss))))

    # ---------- 顺序（只有学校要求按顺序时才查） ----------
    if policy.must_points and policy.sequence is True and samples:
        first_hit = []
        for idx, mp in enumerate(policy.must_points):
            for i, s in enumerate(samples):
                if T.haversine(mp.lat, mp.lng, float(s["lat"]), float(s["lng"])) <= mp.radius:
                    first_hit.append((i, idx, mp.name))
                    break
        hit_order = [h[1] for h in sorted(first_hit)]
        checks.append(Check("打卡顺序", hit_order == sorted(hit_order),
                            "按顺序经过" if hit_order == sorted(hit_order)
                            else "实际经过顺序 %s，与下发顺序不一致" % hit_order,
                            level=_soft("打卡顺序")))

    return checks


def plan_and_check(policy: P.Policy, points: Sequence[Any], *, run_type: Optional[int] = None,
                   identify: str = "", start_ms: Optional[int] = None,
                   seed: Optional[int] = None) -> Tuple[Plan, Optional[Dict[str, Any]], List[Check]]:
    """一步到位：build → 生成 → verify。离线自测和真跑前的"预演"都用这个。"""
    plan = build(policy, points, run_type=run_type, identify=identify,
                 start_ms=start_ms, seed=seed)
    if not plan.ok:
        return plan, None, []
    gen = T.generate(**plan.params)
    return plan, gen, verify(policy, gen)
